/*
 * Copyright (c) 2004, 2011, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package de.ing.security.util;

/**
 * A utility class for handle path list
 */
public class PathList {
    /**
     * Utility method for appending path from pathFrom to pathTo.
     *
     * @param pathTo   the target path
     * @param pathFrom the path to be appended to pathTo
     * @return the resulting path
     */
    public static String appendPath(String pathTo, String pathFrom) {
        if (pathTo == null || pathTo.length() == 0) {
            return pathFrom;
        } else if (pathFrom == null || pathFrom.length() == 0) {
            return pathTo;
        } else {
            return pathTo + java.io.File.pathSeparator + pathFrom;
        }
    }

    /**
     * Returns the directory or JAR file URL corresponding to the specified
     * local file name.
     *
     * @param file the File object
     * @return the resulting directory or JAR file URL, or null if unknown
     */
    private static java.net.URL fileToURL(java.io.File file) {
        String name;
        try {
            name = file.getCanonicalPath();
        } catch (java.io.IOException e) {
            name = file.getAbsolutePath();
        }
        name = name.replace(java.io.File.separatorChar, '/');
        if (!name.startsWith("/")) {
            name = "/" + name;
        }
        // If the file does not exist, then assume that it's a directory
        if (!file.isFile()) {
            name = name + "/";
        }
        try {
            return new java.net.URL("file", "", name);
        } catch (java.net.MalformedURLException e) {
            throw new IllegalArgumentException("file");
        }
    }

    /**
     * Utility method for converting a search path string to an array
     * of directory and JAR file URLs.
     *
     * @param path the search path string
     * @return the resulting array of directory and JAR file URLs
     */
    public static java.net.URL[] pathToURLs(String path) {
        java.util.StringTokenizer st = new java.util.StringTokenizer(path, java.io.File.pathSeparator);
        java.net.URL[] urls = new java.net.URL[st.countTokens()];
        int count = 0;
        while (st.hasMoreTokens()) {
            java.net.URL url = fileToURL(new java.io.File(st.nextToken()));
            if (url != null) {
                urls[count++] = url;
            }
        }
        if (urls.length != count) {
            java.net.URL[] tmp = new java.net.URL[count];
            System.arraycopy(urls, 0, tmp, 0, count);
            urls = tmp;
        }
        return urls;
    }
}
