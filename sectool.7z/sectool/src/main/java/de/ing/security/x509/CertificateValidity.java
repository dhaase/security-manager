/*
 * Copyright (c) 1997, 2011, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */
package de.ing.security.x509;

import de.ing.security.util.DerInputStream;
import de.ing.security.util.DerOutputStream;
import de.ing.security.util.DerValue;

import java.io.IOException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateNotYetValidException;

/**
 * This class defines the interval for which the certificate is valid.
 *
 * @author Amit Kapoor
 * @author Hemma Prafullchandra
 * @see CertAttrSet
 */
public class CertificateValidity implements CertAttrSet<String> {
    /**
     * Identifier for this attribute, to be used with the
     * get, set, delete methods of Certificate, x509 type.
     */
    public static final String IDENT = "x509.info.validity";
    /**
     * Sub attributes name for this CertAttrSet.
     */
    public static final String NAME = "validity";
    public static final String NOT_AFTER = "notAfter";
    public static final String NOT_BEFORE = "notBefore";
    private static final long YR_2050 = 2524636800000L;
    private java.util.Date notAfter;
    // Private data members
    private java.util.Date notBefore;

    /**
     * Default constructor for the class.
     */
    public CertificateValidity() {
    }

    /**
     * The default constructor for this class for the specified interval.
     *
     * @param notBefore the date and time before which the certificate
     *                  is not valid.
     * @param notAfter  the date and time after which the certificate is
     *                  not valid.
     */
    public CertificateValidity(java.util.Date notBefore, java.util.Date notAfter) {
        this.notBefore = notBefore;
        this.notAfter = notAfter;
    }

    /**
     * Create the object, decoding the values from the passed DER stream.
     *
     * @param in the DerInputStream to read the CertificateValidity from.
     * @throws IOException on decoding errors.
     */
    public CertificateValidity(DerInputStream in) throws java.io.IOException {
        DerValue derVal = in.getDerValue();
        construct(derVal);
    }

    // Construct the class from the DerValue
    private void construct(DerValue derVal) throws java.io.IOException {
        if (derVal.tag != DerValue.tag_Sequence) {
            throw new java.io.IOException("Invalid encoded CertificateValidity, " +
                    "starting sequence tag missing.");
        }
        // check if UTCTime encoded or GeneralizedTime
        if (derVal.data.available() == 0)
            throw new java.io.IOException("No data encoded for CertificateValidity");

        DerInputStream derIn = new DerInputStream(derVal.toByteArray());
        DerValue[] seq = derIn.getSequence(2);
        if (seq.length != 2)
            throw new java.io.IOException("Invalid encoding for CertificateValidity");

        if (seq[0].tag == DerValue.tag_UtcTime) {
            notBefore = derVal.data.getUTCTime();
        } else if (seq[0].tag == DerValue.tag_GeneralizedTime) {
            notBefore = derVal.data.getGeneralizedTime();
        } else {
            throw new java.io.IOException("Invalid encoding for CertificateValidity");
        }

        if (seq[1].tag == DerValue.tag_UtcTime) {
            notAfter = derVal.data.getUTCTime();
        } else if (seq[1].tag == DerValue.tag_GeneralizedTime) {
            notAfter = derVal.data.getGeneralizedTime();
        } else {
            throw new java.io.IOException("Invalid encoding for CertificateValidity");
        }
    }

    /**
     * Delete the attribute value.
     */
    public void delete(String name) throws java.io.IOException {
        if (name.equalsIgnoreCase(NOT_BEFORE)) {
            notBefore = null;
        } else if (name.equalsIgnoreCase(NOT_AFTER)) {
            notAfter = null;
        } else {
            throw new java.io.IOException("Attribute name not recognized by " +
                    "CertAttrSet: CertificateValidity.");
        }
    }

    /**
     * Encode the CertificateValidity period in DER form to the stream.
     *
     * @param out the OutputStream to marshal the contents to.
     * @throws IOException on errors.
     */
    public void encode(java.io.OutputStream out) throws java.io.IOException {

        // in cases where default constructor is used check for
        // null values
        if (notBefore == null || notAfter == null) {
            throw new java.io.IOException("CertAttrSet:CertificateValidity:" +
                    " null values to encode.\n");
        }
        DerOutputStream pair = new DerOutputStream();

        if (notBefore.getTime() < YR_2050) {
            pair.putUTCTime(notBefore);
        } else
            pair.putGeneralizedTime(notBefore);

        if (notAfter.getTime() < YR_2050) {
            pair.putUTCTime(notAfter);
        } else {
            pair.putGeneralizedTime(notAfter);
        }
        DerOutputStream seq = new DerOutputStream();
        seq.write(DerValue.tag_Sequence, pair);

        out.write(seq.toByteArray());
    }

    /**
     * Get the attribute value.
     */
    public java.util.Date get(String name) throws java.io.IOException {
        if (name.equalsIgnoreCase(NOT_BEFORE)) {
            return (getNotBefore());
        } else if (name.equalsIgnoreCase(NOT_AFTER)) {
            return (getNotAfter());
        } else {
            throw new java.io.IOException("Attribute name not recognized by " +
                    "CertAttrSet: CertificateValidity.");
        }
    }

    /**
     * Return an enumeration of names of attributes existing within this
     * attribute.
     */
    public java.util.Enumeration<String> getElements() {
        AttributeNameEnumeration elements = new AttributeNameEnumeration();
        elements.addElement(NOT_BEFORE);
        elements.addElement(NOT_AFTER);

        return (elements.elements());
    }

    /**
     * Return the name of this attribute.
     */
    public String getName() {
        return (NAME);
    }

    // Returns the last time the certificate is valid.
    private java.util.Date getNotAfter() {
        return (new java.util.Date(notAfter.getTime()));
    }

    // Returns the first time the certificate is valid.
    private java.util.Date getNotBefore() {
        return (new java.util.Date(notBefore.getTime()));
    }

    /**
     * Set the attribute value.
     */
    public void set(String name, Object obj) throws java.io.IOException {
        if (!(obj instanceof java.util.Date)) {
            throw new java.io.IOException("Attribute must be of type Date.");
        }
        if (name.equalsIgnoreCase(NOT_BEFORE)) {
            notBefore = (java.util.Date) obj;
        } else if (name.equalsIgnoreCase(NOT_AFTER)) {
            notAfter = (java.util.Date) obj;
        } else {
            throw new java.io.IOException("Attribute name not recognized by " +
                    "CertAttrSet: CertificateValidity.");
        }
    }

    /**
     * Return the validity period as user readable string.
     */
    public String toString() {
        if (notBefore == null || notAfter == null)
            return "";
        return ("Validity: [From: " + notBefore.toString() +
                ",\n               To: " + notAfter.toString() + "]");
    }

    /**
     * Verify that the current time is within the validity period.
     *
     * @throws CertificateExpiredException     if the certificate has expired.
     * @throws CertificateNotYetValidException if the certificate is not
     *                                         yet valid.
     */
    public void valid()
            throws java.security.cert.CertificateNotYetValidException, java.security.cert.CertificateExpiredException {
        java.util.Date now = new java.util.Date();
        valid(now);
    }

    /**
     * Verify that the passed time is within the validity period.
     *
     * @param now the Date against which to compare the validity
     *            period.
     * @throws CertificateExpiredException     if the certificate has expired
     *                                         with respect to the <code>Date</code> supplied.
     * @throws CertificateNotYetValidException if the certificate is not
     *                                         yet valid with respect to the <code>Date</code> supplied.
     */
    public void valid(java.util.Date now)
            throws java.security.cert.CertificateNotYetValidException, java.security.cert.CertificateExpiredException {
        /*
         * we use the internal Dates rather than the passed in Date
         * because someone could override the Date methods after()
         * and before() to do something entirely different.
         */
        if (notBefore.after(now)) {
            throw new java.security.cert.CertificateNotYetValidException("NotBefore: " +
                    notBefore.toString());
        }
        if (notAfter.before(now)) {
            throw new java.security.cert.CertificateExpiredException("NotAfter: " +
                    notAfter.toString());
        }
    }
}
