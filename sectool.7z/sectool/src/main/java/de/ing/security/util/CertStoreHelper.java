/*
 * Copyright (c) 2009, 2012, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package de.ing.security.util;

/**
 * Helper used by URICertStore and others when delegating to another CertStore
 * to fetch certs and CRLs.
 */

public abstract class CertStoreHelper {

    private static final int NUM_TYPES = 2;
    private final static java.util.Map<String, String> classMap = new java.util.HashMap<>(NUM_TYPES);
    private static Cache<String, CertStoreHelper> cache
            = Cache.newSoftMemoryCache(NUM_TYPES);

    ;

    static {
        classMap.put(
                "LDAP",
                "sun.security.provider.certpath.ldap.LDAPCertStoreHelper");
        classMap.put(
                "SSLServer",
                "sun.security.provider.certpath.ssl.SSLServerCertStoreHelper");
    }

    public static CertStoreHelper getInstance(final String type)
            throws java.security.NoSuchAlgorithmException {
        CertStoreHelper helper = cache.get(type);
        if (helper != null) {
            return helper;
        }
        final String cl = classMap.get(type);
        if (cl == null) {
            throw new java.security.NoSuchAlgorithmException(type + " not available");
        }
        try {
            helper = java.security.AccessController.doPrivileged(
                    new java.security.PrivilegedExceptionAction<CertStoreHelper>() {
                        public CertStoreHelper run() throws ClassNotFoundException {
                            try {
                                Class<?> c = Class.forName(cl, true, null);
                                CertStoreHelper csh
                                        = (CertStoreHelper) c.newInstance();
                                cache.put(type, csh);
                                return csh;
                            } catch (InstantiationException |
                                    IllegalAccessException e) {
                                throw new AssertionError(e);
                            }
                        }
                    });
            return helper;
        } catch (java.security.PrivilegedActionException e) {
            throw new java.security.NoSuchAlgorithmException(type + " not available",
                    e.getException());
        }
    }

    static boolean isCausedByNetworkIssue(String type, java.security.cert.CertStoreException cse) {
        switch (type) {
            case "LDAP":
            case "SSLServer":
                try {
                    CertStoreHelper csh = CertStoreHelper.getInstance(type);
                    return csh.isCausedByNetworkIssue(cse);
                } catch (java.security.NoSuchAlgorithmException nsae) {
                    return false;
                }
            case "URI":
                Throwable t = cse.getCause();
                return (t != null && t instanceof java.io.IOException);
            default:
                // we don't know about any other remote CertStore types
                return false;
        }
    }

    /**
     * Returns a CertStore using the given URI as parameters.
     */
    public abstract java.security.cert.CertStore getCertStore(java.net.URI uri)
            throws java.security.NoSuchAlgorithmException, java.security.InvalidAlgorithmParameterException;

    /**
     * Returns true if the cause of the CertStoreException is a network
     * related issue.
     */
    public abstract boolean isCausedByNetworkIssue(java.security.cert.CertStoreException e);

    /**
     * Wraps an existing X509CRLSelector when needing to avoid DN matching
     * issues.
     */
    public abstract java.security.cert.X509CRLSelector wrap(java.security.cert.X509CRLSelector selector,
                                                            java.util.Collection<javax.security.auth.x500.X500Principal> certIssuers,
                                                            String dn)
            throws java.io.IOException;

    /**
     * Wraps an existing X509CertSelector when needing to avoid DN matching
     * issues.
     */
    public abstract java.security.cert.X509CertSelector wrap(java.security.cert.X509CertSelector selector,
                                                             javax.security.auth.x500.X500Principal certSubject,
                                                             String dn)
            throws java.io.IOException;
}
