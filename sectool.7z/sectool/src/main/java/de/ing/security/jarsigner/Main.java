/*
 * Copyright (c) 1997, 2013, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package de.ing.security.jarsigner;

import de.ing.security.util.DerInputStream;
import de.ing.security.util.DerValue;
import de.ing.security.util.KeyStoreUtil;
import de.ing.security.util.ManifestDigester;
import de.ing.security.util.Password;
import de.ing.security.util.PathList;
import de.ing.security.util.SignatureFileVerifier;
import de.ing.security.x509.AlgorithmId;
import de.ing.security.x509.NetscapeCertTypeExtension;
import de.ing.security.x509.X500Name;
import de.ing.security.x509.X509CertInfo;

import java.io.IOException;


/*
 * This object encapsulates the parameters used to perform content signing.
 */
class JarSignerParameters implements ContentSignerParameters {

    private String[] args;
    private byte[] content;
    private byte[] signature;
    private String signatureAlgorithm;
    private java.security.cert.X509Certificate[] signerCertificateChain;
    private java.util.zip.ZipFile source;
    private String tSAPolicyID;
    private java.net.URI tsa;
    private java.security.cert.X509Certificate tsaCertificate;

    /**
     * Create a new object.
     */
    JarSignerParameters(String[] args, java.net.URI tsa, java.security.cert.X509Certificate tsaCertificate,
                        String tSAPolicyID,
                        byte[] signature, String signatureAlgorithm,
                        java.security.cert.X509Certificate[] signerCertificateChain, byte[] content,
                        java.util.zip.ZipFile source) {

        if (signature == null || signatureAlgorithm == null ||
                signerCertificateChain == null) {
            throw new NullPointerException();
        }
        this.args = args;
        this.tsa = tsa;
        this.tsaCertificate = tsaCertificate;
        this.tSAPolicyID = tSAPolicyID;
        this.signature = signature;
        this.signatureAlgorithm = signatureAlgorithm;
        this.signerCertificateChain = signerCertificateChain;
        this.content = content;
        this.source = source;
    }

    /**
     * Retrieves the command-line arguments.
     *
     * @return The command-line arguments. May be null.
     */
    public String[] getCommandLine() {
        return args;
    }

    /**
     * Retrieves the content that was signed.
     *
     * @return The content bytes. May be null.
     */
    public byte[] getContent() {
        return content;
    }

    /**
     * Retrieves the signature.
     *
     * @return The non-null signature bytes.
     */
    public byte[] getSignature() {
        return signature;
    }

    /**
     * Retrieves the name of the signature algorithm.
     *
     * @return The non-null string name of the signature algorithm.
     */
    public String getSignatureAlgorithm() {
        return signatureAlgorithm;
    }

    /**
     * Retrieves the signer's X.509 certificate chain.
     *
     * @return The non-null array of X.509 public-key certificates.
     */
    public java.security.cert.X509Certificate[] getSignerCertificateChain() {
        return signerCertificateChain;
    }

    /**
     * Retrieves the original source ZIP file before it was signed.
     *
     * @return The original ZIP file. May be null.
     */
    public java.util.zip.ZipFile getSource() {
        return source;
    }

    public String getTSAPolicyID() {
        return tSAPolicyID;
    }

    /**
     * Retrieves the identifier for a Timestamping Authority (TSA).
     *
     * @return The TSA identifier. May be null.
     */
    public java.net.URI getTimestampingAuthority() {
        return tsa;
    }

    /**
     * Retrieves the certificate for a Timestamping Authority (TSA).
     *
     * @return The TSA certificate. May be null.
     */
    public java.security.cert.X509Certificate getTimestampingAuthorityCertificate() {
        return tsaCertificate;
    }
}

/**
 * <p>The jarsigner utility.
 * <p>
 * The exit codes for the main method are:
 * <p>
 * 0: success
 * 1: any error that the jar cannot be signed or verified, including:
 * keystore loading error
 * TSP communication error
 * jarsigner command line error...
 * otherwise: error codes from -strict
 *
 * @author Roland Schemers
 * @author Jan Luehe
 */

public class Main {

    static final int IN_KEYSTORE = 0x01;        // signer is in keystore
    static final int IN_SCOPE = 0x02;
    static final int NOT_ALIAS = 0x04;          // alias list is NOT empty and
    // signer is not in alias list
    static final int SIGNED_BY_ALIAS = 0x08;    // signer is in alias list
    static final String VERSION = "1.0";
    private static final String META_INF = "META-INF/";
    private static final String NONE = "NONE";
    private static final String P11KEYSTORE = "PKCS11";
    private static final Class<?>[] PARAM_STRING = {String.class};
    private static final long SIX_MONTHS = 180 * 24 * 60 * 60 * 1000L; //milliseconds
    private static final java.text.Collator collator = java.text.Collator.getInstance();
    // for i18n
    private static final java.util.ResourceBundle rb =
            java.util.ResourceBundle.getBundle
                    ("sun.security.tools.jarsigner.Resources");
    private static java.text.MessageFormat expiredTimeForm = null;
    private static java.text.MessageFormat expiringTimeForm = null;
    private static java.text.MessageFormat notYetTimeForm = null;
    private static java.text.MessageFormat signTimeForm = null;
    private static java.text.MessageFormat validityTimeForm = null;
    // or the default keystore, never null

    static {
        // this is for case insensitive string comparisions
        collator.setStrength(java.text.Collator.PRIMARY);
    }

    String alias;    // alias to sign jar with
    String altCertChain; // file to read alternative cert chain from
    java.util.Map<java.security.CodeSigner, String> cacheForSignerInfo = new java.util.IdentityHashMap<>();
    java.security.cert.X509Certificate[] certChain;    // signer's cert chain (when composing)
    java.security.cert.CertificateFactory certificateFactory;
    java.util.List<String> ckaliases = new java.util.ArrayList<>(); // aliases in -verify
    boolean debug = false; // debug
    String digestalg = "SHA-256"; // name of digest algorithm
    boolean externalSF = true; // leave the .SF out of the PKCS7 block
    String jarfile;  // jar files to sign or verify
    char[] keypass; // private key password
    String keystore; // key store file
    boolean nullStream = false; // null keystore input stream (NONE)
    java.security.cert.PKIXParameters pkixParameters;
    java.security.PrivateKey privateKey;          // private key
    boolean protectedPath; // protected authentication path
    // arguments for provider constructors
    java.util.HashMap<String, String> providerArgs = new java.util.HashMap<>();
    String providerName; // provider name
    java.util.Vector<String> providers = null; // list of providers
    boolean showcerts = false; // show certs when verifying
    String sigalg; // name of signature algorithm
    String sigfile; // name of .SF file
    boolean signManifest = true; // "sign" the whole manifest
    String signedjar; // output filename
    java.security.KeyStore store;                 // the keystore specified by -keystore
    java.util.Hashtable<java.security.cert.Certificate, String> storeHash = new java.util.Hashtable<>();
    char[] storepass; // keystore password
    String storetype; // keystore type
    boolean strict = false;  // treat warnings as error
    String tSAPolicyID;
    boolean token = false; // token-based keystore
    String tsaAlias; // alias for the Timestamping Authority's certificate
    String tsaUrl; // location of the Timestamping Authority
    java.security.cert.CertPathValidator validator;
    String verbose = null; // verbose output when signing/verifying
    boolean verify = false; // verify the jar
    private boolean aliasNotInStore = false;
    private String altSignerClass = null;
    private String altSignerClasspath = null;
    private boolean badExtendedKeyUsage = false;
    private boolean badKeyUsage = false;
    private boolean badNetscapeCertType = false;
    // read zip entry raw bytes
    private java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream(2048);
    private byte[] buffer = new byte[8192];
    private java.util.Map<java.security.CodeSigner, Integer> cacheForInKS = new java.util.IdentityHashMap<>();
    private boolean chainNotValidated = false;
    private java.util.Date expireDate = new java.util.Date(0L);     // used in noTimestamp warning
    // Severe warnings
    private boolean hasExpiredCert = false;
    // Informational warnings
    private boolean hasExpiringCert = false;
    private boolean hasUnsignedEntry = false;
    private boolean noTimestamp = false;
    private boolean notSignedByAlias = false;
    private boolean notYetValidCert = false;
    private ContentSigner signingMechanism = null;
    private java.util.zip.ZipFile zipFile = null;

    static void fullusage() {
        System.out.println(rb.getString
                ("Usage.jarsigner.options.jar.file.alias"));
        System.out.println(rb.getString
                (".jarsigner.verify.options.jar.file.alias."));
        System.out.println();
        System.out.println(rb.getString
                (".keystore.url.keystore.location"));
        System.out.println();
        System.out.println(rb.getString
                (".storepass.password.password.for.keystore.integrity"));
        System.out.println();
        System.out.println(rb.getString
                (".storetype.type.keystore.type"));
        System.out.println();
        System.out.println(rb.getString
                (".keypass.password.password.for.private.key.if.different."));
        System.out.println();
        System.out.println(rb.getString
                (".certchain.file.name.of.alternative.certchain.file"));
        System.out.println();
        System.out.println(rb.getString
                (".sigfile.file.name.of.SF.DSA.file"));
        System.out.println();
        System.out.println(rb.getString
                (".signedjar.file.name.of.signed.JAR.file"));
        System.out.println();
        System.out.println(rb.getString
                (".digestalg.algorithm.name.of.digest.algorithm"));
        System.out.println();
        System.out.println(rb.getString
                (".sigalg.algorithm.name.of.signature.algorithm"));
        System.out.println();
        System.out.println(rb.getString
                (".verify.verify.a.signed.JAR.file"));
        System.out.println();
        System.out.println(rb.getString
                (".verbose.suboptions.verbose.output.when.signing.verifying."));
        System.out.println(rb.getString
                (".suboptions.can.be.all.grouped.or.summary"));
        System.out.println();
        System.out.println(rb.getString
                (".certs.display.certificates.when.verbose.and.verifying"));
        System.out.println();
        System.out.println(rb.getString
                (".tsa.url.location.of.the.Timestamping.Authority"));
        System.out.println();
        System.out.println(rb.getString
                (".tsacert.alias.public.key.certificate.for.Timestamping.Authority"));
        System.out.println();
        System.out.println(rb.getString
                (".tsapolicyid.tsapolicyid.for.Timestamping.Authority"));
        System.out.println();
        System.out.println(rb.getString
                (".altsigner.class.class.name.of.an.alternative.signing.mechanism"));
        System.out.println();
        System.out.println(rb.getString
                (".altsignerpath.pathlist.location.of.an.alternative.signing.mechanism"));
        System.out.println();
        System.out.println(rb.getString
                (".internalsf.include.the.SF.file.inside.the.signature.block"));
        System.out.println();
        System.out.println(rb.getString
                (".sectionsonly.don.t.compute.hash.of.entire.manifest"));
        System.out.println();
        System.out.println(rb.getString
                (".protected.keystore.has.protected.authentication.path"));
        System.out.println();
        System.out.println(rb.getString
                (".providerName.name.provider.name"));
        System.out.println();
        System.out.println(rb.getString
                (".providerClass.class.name.of.cryptographic.service.provider.s"));
        System.out.println(rb.getString
                (".providerArg.arg.master.class.file.and.constructor.argument"));
        System.out.println();
        System.out.println(rb.getString
                (".strict.treat.warnings.as.errors"));
        System.out.println();

        System.exit(0);
    }

    static char[] getPass(String modifier, String arg) {
        char[] output = KeyStoreUtil.getPassWithModifier(modifier, arg, rb);
        if (output != null) return output;
        usage();
        return null;    // Useless, usage() already exit
    }

    // Attention:
    // This is the entry that get launched by the security tool jarsigner.
    public static void main(String args[]) throws Exception {
        Main js = new Main();
        js.run(args);
    }

    static void usage() {
        System.out.println();
        System.out.println(rb.getString("Please.type.jarsigner.help.for.usage"));
        System.exit(1);
    }

    static void usageNoArg() {
        System.out.println(rb.getString("Option.lacks.argument"));
        usage();
    }

    /**
     * Check if userCert is designed to be a code signer
     *
     * @param userCert the certificate to be examined
     * @param bad      3 booleans to show if the KeyUsage, ExtendedKeyUsage,
     *                 NetscapeCertType has codeSigning flag turned on.
     *                 If null, the class field badKeyUsage, badExtendedKeyUsage,
     *                 badNetscapeCertType will be set.
     */
    void checkCertUsage(java.security.cert.X509Certificate userCert, boolean[] bad) {

        // Can act as a signer?
        // 1. if KeyUsage, then [0:digitalSignature] or
        //    [1:nonRepudiation] should be true
        // 2. if ExtendedKeyUsage, then should contains ANY or CODE_SIGNING
        // 3. if NetscapeCertType, then should contains OBJECT_SIGNING
        // 1,2,3 must be true

        if (bad != null) {
            bad[0] = bad[1] = bad[2] = false;
        }

        boolean[] keyUsage = userCert.getKeyUsage();
        if (keyUsage != null) {
            keyUsage = java.util.Arrays.copyOf(keyUsage, 9);
            if (!keyUsage[0] && !keyUsage[1]) {
                if (bad != null) {
                    bad[0] = true;
                    badKeyUsage = true;
                }
            }
        }

        try {
            java.util.List<String> xKeyUsage = userCert.getExtendedKeyUsage();
            if (xKeyUsage != null) {
                if (!xKeyUsage.contains("2.5.29.37.0") // anyExtendedKeyUsage
                        && !xKeyUsage.contains("1.3.6.1.5.5.7.3.3")) {  // codeSigning
                    if (bad != null) {
                        bad[1] = true;
                        badExtendedKeyUsage = true;
                    }
                }
            }
        } catch (java.security.cert.CertificateParsingException e) {
            // shouldn't happen
        }

        try {
            // OID_NETSCAPE_CERT_TYPE
            byte[] netscapeEx = userCert.getExtensionValue
                    ("2.16.840.1.113730.1.1");
            if (netscapeEx != null) {
                DerInputStream in = new DerInputStream(netscapeEx);
                byte[] encoded = in.getOctetString();
                encoded = new DerValue(encoded).getUnalignedBitString()
                        .toByteArray();

                NetscapeCertTypeExtension extn =
                        new NetscapeCertTypeExtension(encoded);

                Boolean val = extn.get(NetscapeCertTypeExtension.OBJECT_SIGNING);
                if (!val) {
                    if (bad != null) {
                        bad[2] = true;
                        badNetscapeCertType = true;
                    }
                }
            }
        } catch (java.io.IOException e) {
            //
        }
    }

    void error(String message) {
        System.out.println(rb.getString("jarsigner.") + message);
        System.exit(1);
    }

    void error(String message, Exception e) {
        System.out.println(rb.getString("jarsigner.") + message);
        if (debug) {
            e.printStackTrace();
        }
        System.exit(1);
    }

    /**
     * Find the length of header inside bs. The header is a multiple (>=0)
     * lines of attributes plus an empty line. The empty line is included
     * in the header.
     */
    @SuppressWarnings("fallthrough")
    private int findHeaderEnd(byte[] bs) {
        // Initial state true to deal with empty header
        boolean newline = true;     // just met a newline
        int len = bs.length;
        for (int i = 0; i < len; i++) {
            switch (bs[i]) {
                case '\r':
                    if (i < len - 1 && bs[i + 1] == '\n') i++;
                    // fallthrough
                case '\n':
                    if (newline) return i + 1;    //+1 to get length
                    newline = true;
                    break;
                default:
                    newline = false;
            }
        }
        // If header end is not found, it means the MANIFEST.MF has only
        // the main attributes section and it does not end with 2 newlines.
        // Returns the whole length so that it can be completely replaced.
        return len;
    }

    void getAliasInfo(String alias) {

        java.security.Key key = null;

        try {
            java.security.cert.Certificate[] cs = null;
            if (altCertChain != null) {
                try (java.io.FileInputStream fis = new java.io.FileInputStream(altCertChain)) {
                    cs = java.security.cert.CertificateFactory.getInstance("X.509").
                            generateCertificates(fis).
                            toArray(new java.security.cert.Certificate[0]);
                } catch (java.io.FileNotFoundException ex) {
                    error(rb.getString("File.specified.by.certchain.does.not.exist"));
                } catch (java.security.cert.CertificateException | java.io.IOException ex) {
                    error(rb.getString("Cannot.restore.certchain.from.file.specified"));
                }
            } else {
                try {
                    cs = store.getCertificateChain(alias);
                } catch (java.security.KeyStoreException kse) {
                    // this never happens, because keystore has been loaded
                }
            }
            if (cs == null || cs.length == 0) {
                if (altCertChain != null) {
                    error(rb.getString
                            ("Certificate.chain.not.found.in.the.file.specified."));
                } else {
                    java.text.MessageFormat form = new java.text.MessageFormat(rb.getString
                            ("Certificate.chain.not.found.for.alias.alias.must.reference.a.valid.KeyStore.key.entry.containing.a.private.key.and"));
                    Object[] source = {alias, alias};
                    error(form.format(source));
                }
            }

            certChain = new java.security.cert.X509Certificate[cs.length];
            for (int i = 0; i < cs.length; i++) {
                if (!(cs[i] instanceof java.security.cert.X509Certificate)) {
                    error(rb.getString
                            ("found.non.X.509.certificate.in.signer.s.chain"));
                }
                certChain[i] = (java.security.cert.X509Certificate) cs[i];
            }

            // We don't meant to print anything, the next call
            // checks validity and keyUsage etc
            printCert("", certChain[0], true, null, true);

            try {
                validateCertChain(java.util.Arrays.asList(certChain));
            } catch (Exception e) {
                if (debug) {
                    e.printStackTrace();
                }
                if (e.getCause() != null &&
                        (e.getCause() instanceof java.security.cert.CertificateExpiredException ||
                                e.getCause() instanceof java.security.cert.CertificateNotYetValidException)) {
                    // No more warning, we alreay have hasExpiredCert or notYetValidCert
                } else {
                    chainNotValidated = true;
                }
            }

            try {
                if (!token && keypass == null)
                    key = store.getKey(alias, storepass);
                else
                    key = store.getKey(alias, keypass);
            } catch (java.security.UnrecoverableKeyException e) {
                if (token) {
                    throw e;
                } else if (keypass == null) {
                    // Did not work out, so prompt user for key password
                    java.text.MessageFormat form = new java.text.MessageFormat(rb.getString
                            ("Enter.key.password.for.alias."));
                    Object[] source = {alias};
                    keypass = getPass(form.format(source));
                    key = store.getKey(alias, keypass);
                }
            }
        } catch (java.security.NoSuchAlgorithmException e) {
            error(e.getMessage());
        } catch (java.security.UnrecoverableKeyException e) {
            error(rb.getString("unable.to.recover.key.from.keystore"));
        } catch (java.security.KeyStoreException kse) {
            // this never happens, because keystore has been loaded
        }

        if (!(key instanceof java.security.PrivateKey)) {
            java.text.MessageFormat form = new java.text.MessageFormat(rb.getString
                    ("key.associated.with.alias.not.a.private.key"));
            Object[] source = {alias};
            error(form.format(source));
        } else {
            privateKey = (java.security.PrivateKey) key;
        }
    }

    /*
     * Reads all the bytes for a given zip entry.
     */
    private synchronized byte[] getBytes(java.util.zip.ZipFile zf,
                                         java.util.zip.ZipEntry ze) throws java.io.IOException {
        int n;

        java.io.InputStream is = null;
        try {
            is = zf.getInputStream(ze);
            baos.reset();
            long left = ze.getSize();

            while ((left > 0) && (n = is.read(buffer, 0, buffer.length)) != -1) {
                baos.write(buffer, 0, n);
                left -= n;
            }
        } finally {
            if (is != null) {
                is.close();
            }
        }

        return baos.toByteArray();
    }

    /*
     * Computes the digests of a zip entry, and returns them as a list of
     * attributes
     */
    private java.util.jar.Attributes getDigestAttributes(java.util.zip.ZipEntry ze, java.util.zip.ZipFile zf,
                                                         java.security.MessageDigest[] digests)
            throws java.io.IOException {

        String[] base64Digests = getDigests(ze, zf, digests);
        java.util.jar.Attributes attrs = new java.util.jar.Attributes();

        for (int i = 0; i < digests.length; i++) {
            attrs.putValue(digests[i].getAlgorithm() + "-Digest",
                    base64Digests[i]);
        }
        return attrs;
    }

    /*
     * Computes the digests of a zip entry, and returns them as an array
     * of base64-encoded strings.
     */
    private synchronized String[] getDigests(java.util.zip.ZipEntry ze, java.util.zip.ZipFile zf,
                                             java.security.MessageDigest[] digests)
            throws java.io.IOException {

        int n, i;
        java.io.InputStream is = null;
        try {
            is = zf.getInputStream(ze);
            long left = ze.getSize();
            while ((left > 0)
                    && (n = is.read(buffer, 0, buffer.length)) != -1) {
                for (i = 0; i < digests.length; i++) {
                    digests[i].update(buffer, 0, n);
                }
                left -= n;
            }
        } finally {
            if (is != null) {
                is.close();
            }
        }

        // complete the digests
        String[] base64Digests = new String[digests.length];
        for (i = 0; i < digests.length; i++) {
            base64Digests[i] = java.util.Base64.getEncoder().encodeToString(digests[i].digest());
        }
        return base64Digests;
    }

    /*
     * Returns manifest entry from given jar file, or null if given jar file
     * does not have a manifest entry.
     */
    private java.util.zip.ZipEntry getManifestFile(java.util.zip.ZipFile zf) {
        java.util.zip.ZipEntry ze = zf.getEntry(java.util.jar.JarFile.MANIFEST_NAME);
        if (ze == null) {
            // Check all entries for matching name
            java.util.Enumeration<? extends java.util.zip.ZipEntry> enum_ = zf.entries();
            while (enum_.hasMoreElements() && ze == null) {
                ze = enum_.nextElement();
                if (!java.util.jar.JarFile.MANIFEST_NAME.equalsIgnoreCase
                        (ze.getName())) {
                    ze = null;
                }
            }
        }
        return ze;
    }

    char[] getPass(String prompt) {
        System.err.print(prompt);
        System.err.flush();
        try {
            char[] pass = Password.readPassword(System.in);

            if (pass == null) {
                error(rb.getString("you.must.enter.key.password"));
            } else {
                return pass;
            }
        } catch (java.io.IOException ioe) {
            error(rb.getString("unable.to.read.password.") + ioe.getMessage());
        }
        // this shouldn't happen
        return null;
    }

    java.security.cert.X509Certificate getTsaCert(String alias) {

        java.security.cert.Certificate cs = null;

        try {
            cs = store.getCertificate(alias);
        } catch (java.security.KeyStoreException kse) {
            // this never happens, because keystore has been loaded
        }
        if (cs == null || (!(cs instanceof java.security.cert.X509Certificate))) {
            java.text.MessageFormat form = new java.text.MessageFormat(rb.getString
                    ("Certificate.not.found.for.alias.alias.must.reference.a.valid.KeyStore.entry.containing.an.X.509.public.key.certificate.for.the"));
            Object[] source = {alias, alias};
            error(form.format(source));
        }
        return (java.security.cert.X509Certificate) cs;
    }

    int inKeyStore(java.security.CodeSigner[] signers) {

        if (signers == null)
            return 0;

        int output = 0;

        for (java.security.CodeSigner signer : signers) {
            int result = inKeyStoreForOneSigner(signer);
            output |= result;
        }
        if (ckaliases.size() > 0 && (output & SIGNED_BY_ALIAS) == 0) {
            output |= NOT_ALIAS;
        }
        return output;
    }

    private int inKeyStoreForOneSigner(java.security.CodeSigner signer) {
        if (cacheForInKS.containsKey(signer)) {
            return cacheForInKS.get(signer);
        }

        boolean found = false;
        int result = 0;
        java.util.List<? extends java.security.cert.Certificate> certs = signer.getSignerCertPath().getCertificates();
        for (java.security.cert.Certificate c : certs) {
            String alias = storeHash.get(c);
            if (alias != null) {
                if (alias.startsWith("(")) {
                    result |= IN_KEYSTORE;
                } else if (alias.startsWith("[")) {
                    result |= IN_SCOPE;
                }
                if (ckaliases.contains(alias.substring(1, alias.length() - 1))) {
                    result |= SIGNED_BY_ALIAS;
                }
            } else {
                if (store != null) {
                    try {
                        alias = store.getCertificateAlias(c);
                    } catch (java.security.KeyStoreException kse) {
                        // never happens, because keystore has been loaded
                    }
                    if (alias != null) {
                        storeHash.put(c, "(" + alias + ")");
                        found = true;
                        result |= IN_KEYSTORE;
                    }
                }
                if (ckaliases.contains(alias)) {
                    result |= SIGNED_BY_ALIAS;
                }
            }
        }
        cacheForInKS.put(signer, result);
        return result;
    }

    void loadKeyStore(String keyStoreName, boolean prompt) {

        if (!nullStream && keyStoreName == null) {
            keyStoreName = System.getProperty("user.home") + java.io.File.separator
                    + ".keystore";
        }

        try {

            certificateFactory = java.security.cert.CertificateFactory.getInstance("X.509");
            validator = java.security.cert.CertPathValidator.getInstance("PKIX");
            java.util.Set<java.security.cert.TrustAnchor> tas = new java.util.HashSet<>();
            try {
                java.security.KeyStore caks = KeyStoreUtil.getCacertsKeyStore();
                if (caks != null) {
                    java.util.Enumeration<String> aliases = caks.aliases();
                    while (aliases.hasMoreElements()) {
                        String a = aliases.nextElement();
                        try {
                            tas.add(new java.security.cert.TrustAnchor((java.security.cert.X509Certificate) caks.getCertificate(a), null));
                        } catch (Exception e2) {
                            // ignore, when a SecretkeyEntry does not include a cert
                        }
                    }
                }
            } catch (Exception e) {
                // Ignore, if cacerts cannot be loaded
            }

            if (providerName == null) {
                store = java.security.KeyStore.getInstance(storetype);
            } else {
                store = java.security.KeyStore.getInstance(storetype, providerName);
            }

            // Get pass phrase
            // XXX need to disable echo; on UNIX, call getpass(char *prompt)Z
            // and on NT call ??
            if (token && storepass == null && !protectedPath
                    && !KeyStoreUtil.isWindowsKeyStore(storetype)) {
                storepass = getPass
                        (rb.getString("Enter.Passphrase.for.keystore."));
            } else if (!token && storepass == null && prompt) {
                storepass = getPass
                        (rb.getString("Enter.Passphrase.for.keystore."));
            }

            try {
                if (nullStream) {
                    store.load(null, storepass);
                } else {
                    keyStoreName = keyStoreName.replace(java.io.File.separatorChar, '/');
                    java.net.URL url = null;
                    try {
                        url = new java.net.URL(keyStoreName);
                    } catch (java.net.MalformedURLException e) {
                        // try as file
                        url = new java.io.File(keyStoreName).toURI().toURL();
                    }
                    java.io.InputStream is = null;
                    try {
                        is = url.openStream();
                        store.load(is, storepass);
                    } finally {
                        if (is != null) {
                            is.close();
                        }
                    }
                }
                java.util.Enumeration<String> aliases = store.aliases();
                while (aliases.hasMoreElements()) {
                    String a = aliases.nextElement();
                    try {
                        java.security.cert.X509Certificate c = (java.security.cert.X509Certificate) store.getCertificate(a);
                        // Only add TrustedCertificateEntry and self-signed
                        // PrivateKeyEntry
                        if (store.isCertificateEntry(a) ||
                                c.getSubjectDN().equals(c.getIssuerDN())) {
                            tas.add(new java.security.cert.TrustAnchor(c, null));
                        }
                    } catch (Exception e2) {
                        // ignore, when a SecretkeyEntry does not include a cert
                    }
                }
            } finally {
                try {
                    pkixParameters = new java.security.cert.PKIXParameters(tas);
                    pkixParameters.setRevocationEnabled(false);
                } catch (java.security.InvalidAlgorithmParameterException ex) {
                    // Only if tas is empty
                }
            }
        } catch (java.io.IOException ioe) {
            throw new RuntimeException(rb.getString("keystore.load.") +
                    ioe.getMessage());
        } catch (java.security.cert.CertificateException ce) {
            throw new RuntimeException(rb.getString("certificate.exception.") +
                    ce.getMessage());
        } catch (java.security.NoSuchProviderException pe) {
            throw new RuntimeException(rb.getString("keystore.load.") +
                    pe.getMessage());
        } catch (java.security.NoSuchAlgorithmException nsae) {
            throw new RuntimeException(rb.getString("keystore.load.") +
                    nsae.getMessage());
        } catch (java.security.KeyStoreException kse) {
            throw new RuntimeException
                    (rb.getString("unable.to.instantiate.keystore.class.") +
                            kse.getMessage());
        }
    }

    /*
     * Try to load the specified signing mechanism.
     * The URL class loader is used.
     */
    private ContentSigner loadSigningMechanism(String signerClassName,
                                               String signerClassPath) throws Exception {

        // construct class loader
        String cpString = null;   // make sure env.class.path defaults to dot

        // do prepends to get correct ordering
        cpString = PathList.appendPath(System.getProperty("env.class.path"), cpString);
        cpString = PathList.appendPath(System.getProperty("java.class.path"), cpString);
        cpString = PathList.appendPath(signerClassPath, cpString);
        java.net.URL[] urls = PathList.pathToURLs(cpString);
        ClassLoader appClassLoader = new java.net.URLClassLoader(urls);

        // attempt to find signer
        Class<?> signerClass = appClassLoader.loadClass(signerClassName);

        // Check that it implements ContentSigner
        Object signer = signerClass.newInstance();
        if (!(signer instanceof ContentSigner)) {
            java.text.MessageFormat form = new java.text.MessageFormat(
                    rb.getString("signerClass.is.not.a.signing.mechanism"));
            Object[] source = {signerClass.getName()};
            throw new IllegalArgumentException(form.format(source));
        }
        return (ContentSigner) signer;
    }

    /*
     * Parse command line arguments.
     */
    void parseArgs(String args[]) {
        /* parse flags */
        int n = 0;

        if (args.length == 0) fullusage();
        for (n = 0; n < args.length; n++) {

            String flags = args[n];
            String modifier = null;

            if (flags.startsWith("-")) {
                int pos = flags.indexOf(':');
                if (pos > 0) {
                    modifier = flags.substring(pos + 1);
                    flags = flags.substring(0, pos);
                }
            }

            if (!flags.startsWith("-")) {
                if (jarfile == null) {
                    jarfile = flags;
                } else {
                    alias = flags;
                    ckaliases.add(alias);
                }
            } else if (collator.compare(flags, "-keystore") == 0) {
                if (++n == args.length) usageNoArg();
                keystore = args[n];
            } else if (collator.compare(flags, "-storepass") == 0) {
                if (++n == args.length) usageNoArg();
                storepass = getPass(modifier, args[n]);
            } else if (collator.compare(flags, "-storetype") == 0) {
                if (++n == args.length) usageNoArg();
                storetype = args[n];
            } else if (collator.compare(flags, "-providerName") == 0) {
                if (++n == args.length) usageNoArg();
                providerName = args[n];
            } else if ((collator.compare(flags, "-provider") == 0) ||
                    (collator.compare(flags, "-providerClass") == 0)) {
                if (++n == args.length) usageNoArg();
                if (providers == null) {
                    providers = new java.util.Vector<String>(3);
                }
                providers.add(args[n]);

                if (args.length > (n + 1)) {
                    flags = args[n + 1];
                    if (collator.compare(flags, "-providerArg") == 0) {
                        if (args.length == (n + 2)) usageNoArg();
                        providerArgs.put(args[n], args[n + 2]);
                        n += 2;
                    }
                }
            } else if (collator.compare(flags, "-protected") == 0) {
                protectedPath = true;
            } else if (collator.compare(flags, "-certchain") == 0) {
                if (++n == args.length) usageNoArg();
                altCertChain = args[n];
            } else if (collator.compare(flags, "-tsapolicyid") == 0) {
                if (++n == args.length) usageNoArg();
                tSAPolicyID = args[n];
            } else if (collator.compare(flags, "-debug") == 0) {
                debug = true;
            } else if (collator.compare(flags, "-keypass") == 0) {
                if (++n == args.length) usageNoArg();
                keypass = getPass(modifier, args[n]);
            } else if (collator.compare(flags, "-sigfile") == 0) {
                if (++n == args.length) usageNoArg();
                sigfile = args[n];
            } else if (collator.compare(flags, "-signedjar") == 0) {
                if (++n == args.length) usageNoArg();
                signedjar = args[n];
            } else if (collator.compare(flags, "-tsa") == 0) {
                if (++n == args.length) usageNoArg();
                tsaUrl = args[n];
            } else if (collator.compare(flags, "-tsacert") == 0) {
                if (++n == args.length) usageNoArg();
                tsaAlias = args[n];
            } else if (collator.compare(flags, "-altsigner") == 0) {
                if (++n == args.length) usageNoArg();
                altSignerClass = args[n];
            } else if (collator.compare(flags, "-altsignerpath") == 0) {
                if (++n == args.length) usageNoArg();
                altSignerClasspath = args[n];
            } else if (collator.compare(flags, "-sectionsonly") == 0) {
                signManifest = false;
            } else if (collator.compare(flags, "-internalsf") == 0) {
                externalSF = false;
            } else if (collator.compare(flags, "-verify") == 0) {
                verify = true;
            } else if (collator.compare(flags, "-verbose") == 0) {
                verbose = (modifier != null) ? modifier : "all";
            } else if (collator.compare(flags, "-sigalg") == 0) {
                if (++n == args.length) usageNoArg();
                sigalg = args[n];
            } else if (collator.compare(flags, "-digestalg") == 0) {
                if (++n == args.length) usageNoArg();
                digestalg = args[n];
            } else if (collator.compare(flags, "-certs") == 0) {
                showcerts = true;
            } else if (collator.compare(flags, "-strict") == 0) {
                strict = true;
            } else if (collator.compare(flags, "-h") == 0 ||
                    collator.compare(flags, "-help") == 0) {
                fullusage();
            } else {
                System.err.println(
                        rb.getString("Illegal.option.") + flags);
                usage();
            }
        }

        // -certs must always be specified with -verbose
        if (verbose == null) showcerts = false;

        if (jarfile == null) {
            System.err.println(rb.getString("Please.specify.jarfile.name"));
            usage();
        }
        if (!verify && alias == null) {
            System.err.println(rb.getString("Please.specify.alias.name"));
            usage();
        }
        if (!verify && ckaliases.size() > 1) {
            System.err.println(rb.getString("Only.one.alias.can.be.specified"));
            usage();
        }

        if (storetype == null) {
            storetype = java.security.KeyStore.getDefaultType();
        }
        storetype = KeyStoreUtil.niceStoreTypeName(storetype);

        try {
            if (signedjar != null && new java.io.File(signedjar).getCanonicalPath().equals(
                    new java.io.File(jarfile).getCanonicalPath())) {
                signedjar = null;
            }
        } catch (java.io.IOException ioe) {
            // File system error?
            // Just ignore it.
        }

        if (P11KEYSTORE.equalsIgnoreCase(storetype) ||
                KeyStoreUtil.isWindowsKeyStore(storetype)) {
            token = true;
            if (keystore == null) {
                keystore = NONE;
            }
        }

        if (NONE.equals(keystore)) {
            nullStream = true;
        }

        if (token && !nullStream) {
            System.err.println(java.text.MessageFormat.format(rb.getString
                    (".keystore.must.be.NONE.if.storetype.is.{0}"), storetype));
            usage();
        }

        if (token && keypass != null) {
            System.err.println(java.text.MessageFormat.format(rb.getString
                    (".keypass.can.not.be.specified.if.storetype.is.{0}"), storetype));
            usage();
        }

        if (protectedPath) {
            if (storepass != null || keypass != null) {
                System.err.println(rb.getString
                        ("If.protected.is.specified.then.storepass.and.keypass.must.not.be.specified"));
                usage();
            }
        }
        if (KeyStoreUtil.isWindowsKeyStore(storetype)) {
            if (storepass != null || keypass != null) {
                System.err.println(rb.getString
                        ("If.keystore.is.not.password.protected.then.storepass.and.keypass.must.not.be.specified"));
                usage();
            }
        }
    }

    /*
     * Display some details about a certificate:
     *
     * [<tab>] <cert-type> [", " <subject-DN>] [" (" <keystore-entry-alias> ")"]
     * [<validity-period> | <expiry-warning>]
     *
     * Note: no newline character at the end
     */
    String printCert(String tab, java.security.cert.Certificate c, boolean checkValidityPeriod,
                     java.util.Date timestamp, boolean checkUsage) {

        StringBuilder certStr = new StringBuilder();
        String space = rb.getString("SPACE");
        java.security.cert.X509Certificate x509Cert = null;

        if (c instanceof java.security.cert.X509Certificate) {
            x509Cert = (java.security.cert.X509Certificate) c;
            certStr.append(tab).append(x509Cert.getType())
                    .append(rb.getString("COMMA"))
                    .append(x509Cert.getSubjectDN().getName());
        } else {
            certStr.append(tab).append(c.getType());
        }

        String alias = storeHash.get(c);
        if (alias != null) {
            certStr.append(space).append(alias);
        }

        if (checkValidityPeriod && x509Cert != null) {

            certStr.append("\n").append(tab).append("[");
            java.util.Date notAfter = x509Cert.getNotAfter();
            try {
                boolean printValidity = true;
                if (timestamp == null) {
                    if (expireDate.getTime() == 0 || expireDate.after(notAfter)) {
                        expireDate = notAfter;
                    }
                    x509Cert.checkValidity();
                    // test if cert will expire within six months
                    if (notAfter.getTime() < System.currentTimeMillis() + SIX_MONTHS) {
                        hasExpiringCert = true;
                        if (expiringTimeForm == null) {
                            expiringTimeForm = new java.text.MessageFormat(
                                    rb.getString("certificate.will.expire.on"));
                        }
                        Object[] source = {notAfter};
                        certStr.append(expiringTimeForm.format(source));
                        printValidity = false;
                    }
                } else {
                    x509Cert.checkValidity(timestamp);
                }
                if (printValidity) {
                    if (validityTimeForm == null) {
                        validityTimeForm = new java.text.MessageFormat(
                                rb.getString("certificate.is.valid.from"));
                    }
                    Object[] source = {x509Cert.getNotBefore(), notAfter};
                    certStr.append(validityTimeForm.format(source));
                }
            } catch (java.security.cert.CertificateExpiredException cee) {
                hasExpiredCert = true;

                if (expiredTimeForm == null) {
                    expiredTimeForm = new java.text.MessageFormat(
                            rb.getString("certificate.expired.on"));
                }
                Object[] source = {notAfter};
                certStr.append(expiredTimeForm.format(source));

            } catch (java.security.cert.CertificateNotYetValidException cnyve) {
                notYetValidCert = true;

                if (notYetTimeForm == null) {
                    notYetTimeForm = new java.text.MessageFormat(
                            rb.getString("certificate.is.not.valid.until"));
                }
                Object[] source = {x509Cert.getNotBefore()};
                certStr.append(notYetTimeForm.format(source));
            }
            certStr.append("]");

            if (checkUsage) {
                boolean[] bad = new boolean[3];
                checkCertUsage(x509Cert, bad);
                if (bad[0] || bad[1] || bad[2]) {
                    String x = "";
                    if (bad[0]) {
                        x = "KeyUsage";
                    }
                    if (bad[1]) {
                        if (x.length() > 0) x = x + ", ";
                        x = x + "ExtendedKeyUsage";
                    }
                    if (bad[2]) {
                        if (x.length() > 0) x = x + ", ";
                        x = x + "NetscapeCertType";
                    }
                    certStr.append("\n").append(tab)
                            .append(java.text.MessageFormat.format(rb.getString(
                                    ".{0}.extension.does.not.support.code.signing."), x));
                }
            }
        }
        return certStr.toString();
    }

    private String printTimestamp(String tab, java.security.Timestamp timestamp) {

        if (signTimeForm == null) {
            signTimeForm =
                    new java.text.MessageFormat(rb.getString("entry.was.signed.on"));
        }
        Object[] source = {timestamp.getTimestamp()};

        return new StringBuilder().append(tab).append("[")
                .append(signTimeForm.format(source)).append("]").toString();
    }

    public void run(String args[]) {
        try {
            parseArgs(args);

            // Try to load and install the specified providers
            if (providers != null) {
                ClassLoader cl = ClassLoader.getSystemClassLoader();
                java.util.Enumeration<String> e = providers.elements();
                while (e.hasMoreElements()) {
                    String provName = e.nextElement();
                    Class<?> provClass;
                    if (cl != null) {
                        provClass = cl.loadClass(provName);
                    } else {
                        provClass = Class.forName(provName);
                    }

                    String provArg = providerArgs.get(provName);
                    Object obj;
                    if (provArg == null) {
                        obj = provClass.newInstance();
                    } else {
                        java.lang.reflect.Constructor<?> c =
                                provClass.getConstructor(PARAM_STRING);
                        obj = c.newInstance(provArg);
                    }

                    if (!(obj instanceof java.security.Provider)) {
                        java.text.MessageFormat form = new java.text.MessageFormat(rb.getString
                                ("provName.not.a.provider"));
                        Object[] source = {provName};
                        throw new Exception(form.format(source));
                    }
                    java.security.Security.addProvider((java.security.Provider) obj);
                }
            }

            if (verify) {
                try {
                    loadKeyStore(keystore, false);
                } catch (Exception e) {
                    if ((keystore != null) || (storepass != null)) {
                        System.out.println(rb.getString("jarsigner.error.") +
                                e.getMessage());
                        System.exit(1);
                    }
                }
                /*              if (debug) {
                    SignatureFileVerifier.setDebug(true);
                    ManifestEntryVerifier.setDebug(true);
                }
                */
                verifyJar(jarfile);
            } else {
                loadKeyStore(keystore, true);
                getAliasInfo(alias);

                // load the alternative signing mechanism
                if (altSignerClass != null) {
                    signingMechanism = loadSigningMechanism(altSignerClass,
                            altSignerClasspath);
                }
                signJar(jarfile, alias, args);
            }
        } catch (Exception e) {
            System.out.println(rb.getString("jarsigner.error.") + e);
            if (debug) {
                e.printStackTrace();
            }
            System.exit(1);
        } finally {
            // zero-out private key password
            if (keypass != null) {
                java.util.Arrays.fill(keypass, ' ');
                keypass = null;
            }
            // zero-out keystore password
            if (storepass != null) {
                java.util.Arrays.fill(storepass, ' ');
                storepass = null;
            }
        }

        if (strict) {
            int exitCode = 0;
            if (chainNotValidated || hasExpiredCert || notYetValidCert) {
                exitCode |= 4;
            }
            if (badKeyUsage || badExtendedKeyUsage || badNetscapeCertType) {
                exitCode |= 8;
            }
            if (hasUnsignedEntry) {
                exitCode |= 16;
            }
            if (notSignedByAlias || aliasNotInStore) {
                exitCode |= 32;
            }
            if (exitCode != 0) {
                System.exit(exitCode);
            }
        }
    }

    void signJar(String jarName, String alias, String[] args)
            throws Exception {
        boolean aliasUsed = false;
        java.security.cert.X509Certificate tsaCert = null;

        if (sigfile == null) {
            sigfile = alias;
            aliasUsed = true;
        }

        if (sigfile.length() > 8) {
            sigfile = sigfile.substring(0, 8).toUpperCase(java.util.Locale.ENGLISH);
        } else {
            sigfile = sigfile.toUpperCase(java.util.Locale.ENGLISH);
        }

        StringBuilder tmpSigFile = new StringBuilder(sigfile.length());
        for (int j = 0; j < sigfile.length(); j++) {
            char c = sigfile.charAt(j);
            if (!
                    ((c >= 'A' && c <= 'Z') ||
                            (c >= '0' && c <= '9') ||
                            (c == '-') ||
                            (c == '_'))) {
                if (aliasUsed) {
                    // convert illegal characters from the alias to be _'s
                    c = '_';
                } else {
                    throw new
                            RuntimeException(rb.getString
                            ("signature.filename.must.consist.of.the.following.characters.A.Z.0.9.or."));
                }
            }
            tmpSigFile.append(c);
        }

        sigfile = tmpSigFile.toString();

        String tmpJarName;
        if (signedjar == null) tmpJarName = jarName + ".sig";
        else tmpJarName = signedjar;

        java.io.File jarFile = new java.io.File(jarName);
        java.io.File signedJarFile = new java.io.File(tmpJarName);

        // Open the jar (zip) file
        try {
            zipFile = new java.util.zip.ZipFile(jarName);
        } catch (java.io.IOException ioe) {
            error(rb.getString("unable.to.open.jar.file.") + jarName, ioe);
        }

        java.io.FileOutputStream fos = null;
        try {
            fos = new java.io.FileOutputStream(signedJarFile);
        } catch (java.io.IOException ioe) {
            error(rb.getString("unable.to.create.") + tmpJarName, ioe);
        }

        java.io.PrintStream ps = new java.io.PrintStream(fos);
        java.util.zip.ZipOutputStream zos = new java.util.zip.ZipOutputStream(ps);

        /* First guess at what they might be - we don't xclude RSA ones. */
        String sfFilename = (META_INF + sigfile + ".SF").toUpperCase(java.util.Locale.ENGLISH);
        String bkFilename = (META_INF + sigfile + ".DSA").toUpperCase(java.util.Locale.ENGLISH);

        java.util.jar.Manifest manifest = new java.util.jar.Manifest();
        java.util.Map<String, java.util.jar.Attributes> mfEntries = manifest.getEntries();

        // The Attributes of manifest before updating
        java.util.jar.Attributes oldAttr = null;

        boolean mfModified = false;
        boolean mfCreated = false;
        byte[] mfRawBytes = null;

        try {
            java.security.MessageDigest digests[] = {java.security.MessageDigest.getInstance(digestalg)};

            // Check if manifest exists
            java.util.zip.ZipEntry mfFile;
            if ((mfFile = getManifestFile(zipFile)) != null) {
                // Manifest exists. Read its raw bytes.
                mfRawBytes = getBytes(zipFile, mfFile);
                manifest.read(new java.io.ByteArrayInputStream(mfRawBytes));
                oldAttr = (java.util.jar.Attributes) (manifest.getMainAttributes().clone());
            } else {
                // Create new manifest
                java.util.jar.Attributes mattr = manifest.getMainAttributes();
                mattr.putValue(java.util.jar.Attributes.Name.MANIFEST_VERSION.toString(),
                        "1.0");
                String javaVendor = System.getProperty("java.vendor");
                String jdkVersion = System.getProperty("java.version");
                mattr.putValue("Created-By", jdkVersion + " (" + javaVendor
                        + ")");
                mfFile = new java.util.zip.ZipEntry(java.util.jar.JarFile.MANIFEST_NAME);
                mfCreated = true;
            }

            /*
             * For each entry in jar
             * (except for signature-related META-INF entries),
             * do the following:
             *
             * - if entry is not contained in manifest, add it to manifest;
             * - if entry is contained in manifest, calculate its hash and
             *   compare it with the one in the manifest; if they are
             *   different, replace the hash in the manifest with the newly
             *   generated one. (This may invalidate existing signatures!)
             */
            java.util.Vector<java.util.zip.ZipEntry> mfFiles = new java.util.Vector<>();

            boolean wasSigned = false;

            for (java.util.Enumeration<? extends java.util.zip.ZipEntry> enum_ = zipFile.entries();
                 enum_.hasMoreElements(); ) {
                java.util.zip.ZipEntry ze = enum_.nextElement();

                if (ze.getName().startsWith(META_INF)) {
                    // Store META-INF files in vector, so they can be written
                    // out first
                    mfFiles.addElement(ze);

                    if (SignatureFileVerifier.isBlockOrSF(
                            ze.getName().toUpperCase(java.util.Locale.ENGLISH))) {
                        wasSigned = true;
                    }

                    if (signatureRelated(ze.getName())) {
                        // ignore signature-related and manifest files
                        continue;
                    }
                }

                if (manifest.getAttributes(ze.getName()) != null) {
                    // jar entry is contained in manifest, check and
                    // possibly update its digest attributes
                    if (updateDigests(ze, zipFile, digests,
                            manifest) == true) {
                        mfModified = true;
                    }
                } else if (!ze.isDirectory()) {
                    // Add entry to manifest
                    java.util.jar.Attributes attrs = getDigestAttributes(ze, zipFile,
                            digests);
                    mfEntries.put(ze.getName(), attrs);
                    mfModified = true;
                }
            }

            // Recalculate the manifest raw bytes if necessary
            if (mfModified) {
                java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                manifest.write(baos);
                if (wasSigned) {
                    byte[] newBytes = baos.toByteArray();
                    if (mfRawBytes != null
                            && oldAttr.equals(manifest.getMainAttributes())) {

                        /*
                         * Note:
                         *
                         * The Attributes object is based on HashMap and can handle
                         * continuation columns. Therefore, even if the contents are
                         * not changed (in a Map view), the bytes that it write()
                         * may be different from the original bytes that it read()
                         * from. Since the signature on the main attributes is based
                         * on raw bytes, we must retain the exact bytes.
                         */

                        int newPos = findHeaderEnd(newBytes);
                        int oldPos = findHeaderEnd(mfRawBytes);

                        if (newPos == oldPos) {
                            System.arraycopy(mfRawBytes, 0, newBytes, 0, oldPos);
                        } else {
                            // cat oldHead newTail > newBytes
                            byte[] lastBytes = new byte[oldPos +
                                    newBytes.length - newPos];
                            System.arraycopy(mfRawBytes, 0, lastBytes, 0, oldPos);
                            System.arraycopy(newBytes, newPos, lastBytes, oldPos,
                                    newBytes.length - newPos);
                            newBytes = lastBytes;
                        }
                    }
                    mfRawBytes = newBytes;
                } else {
                    mfRawBytes = baos.toByteArray();
                }
            }

            // Write out the manifest
            if (mfModified) {
                // manifest file has new length
                mfFile = new java.util.zip.ZipEntry(java.util.jar.JarFile.MANIFEST_NAME);
            }
            if (verbose != null) {
                if (mfCreated) {
                    System.out.println(rb.getString(".adding.") +
                            mfFile.getName());
                } else if (mfModified) {
                    System.out.println(rb.getString(".updating.") +
                            mfFile.getName());
                }
            }
            zos.putNextEntry(mfFile);
            zos.write(mfRawBytes);

            // Calculate SignatureFile (".SF") and SignatureBlockFile
            ManifestDigester manDig = new ManifestDigester(mfRawBytes);
            SignatureFile sf = new SignatureFile(digests, manifest, manDig,
                    sigfile, signManifest);

            if (tsaAlias != null) {
                tsaCert = getTsaCert(tsaAlias);
            }

            if (tsaUrl == null && tsaCert == null) {
                noTimestamp = true;
            }

            SignatureFile.Block block = null;

            try {
                block =
                        sf.generateBlock(privateKey, sigalg, certChain,
                                externalSF, tsaUrl, tsaCert, tSAPolicyID, signingMechanism, args,
                                zipFile);
            } catch (java.net.SocketTimeoutException e) {
                // Provide a helpful message when TSA is beyond a firewall
                error(rb.getString("unable.to.sign.jar.") +
                        rb.getString("no.response.from.the.Timestamping.Authority.") +
                        "\n  -J-Dhttp.proxyHost=<hostname>" +
                        "\n  -J-Dhttp.proxyPort=<portnumber>\n" +
                        rb.getString("or") +
                        "\n  -J-Dhttps.proxyHost=<hostname> " +
                        "\n  -J-Dhttps.proxyPort=<portnumber> ", e);
            }

            sfFilename = sf.getMetaName();
            bkFilename = block.getMetaName();

            java.util.zip.ZipEntry sfFile = new java.util.zip.ZipEntry(sfFilename);
            java.util.zip.ZipEntry bkFile = new java.util.zip.ZipEntry(bkFilename);

            long time = System.currentTimeMillis();
            sfFile.setTime(time);
            bkFile.setTime(time);

            // signature file
            zos.putNextEntry(sfFile);
            sf.write(zos);
            if (verbose != null) {
                if (zipFile.getEntry(sfFilename) != null) {
                    System.out.println(rb.getString(".updating.") +
                            sfFilename);
                } else {
                    System.out.println(rb.getString(".adding.") +
                            sfFilename);
                }
            }

            if (verbose != null) {
                if (tsaUrl != null || tsaCert != null) {
                    System.out.println(
                            rb.getString("requesting.a.signature.timestamp"));
                }
                if (tsaUrl != null) {
                    System.out.println(rb.getString("TSA.location.") + tsaUrl);
                }
                if (tsaCert != null) {
                    java.net.URI tsaURI = TimestampedSigner.getTimestampingURI(tsaCert);
                    if (tsaURI != null) {
                        System.out.println(rb.getString("TSA.location.") +
                                tsaURI);
                    }
                    System.out.println(rb.getString("TSA.certificate.") +
                            printCert("", tsaCert, false, null, false));
                }
                if (signingMechanism != null) {
                    System.out.println(
                            rb.getString("using.an.alternative.signing.mechanism"));
                }
            }

            // signature block file
            zos.putNextEntry(bkFile);
            block.write(zos);
            if (verbose != null) {
                if (zipFile.getEntry(bkFilename) != null) {
                    System.out.println(rb.getString(".updating.") +
                            bkFilename);
                } else {
                    System.out.println(rb.getString(".adding.") +
                            bkFilename);
                }
            }

            // Write out all other META-INF files that we stored in the
            // vector
            for (int i = 0; i < mfFiles.size(); i++) {
                java.util.zip.ZipEntry ze = mfFiles.elementAt(i);
                if (!ze.getName().equalsIgnoreCase(java.util.jar.JarFile.MANIFEST_NAME)
                        && !ze.getName().equalsIgnoreCase(sfFilename)
                        && !ze.getName().equalsIgnoreCase(bkFilename)) {
                    writeEntry(zipFile, zos, ze);
                }
            }

            // Write out all other files
            for (java.util.Enumeration<? extends java.util.zip.ZipEntry> enum_ = zipFile.entries();
                 enum_.hasMoreElements(); ) {
                java.util.zip.ZipEntry ze = enum_.nextElement();

                if (!ze.getName().startsWith(META_INF)) {
                    if (verbose != null) {
                        if (manifest.getAttributes(ze.getName()) != null)
                            System.out.println(rb.getString(".signing.") +
                                    ze.getName());
                        else
                            System.out.println(rb.getString(".adding.") +
                                    ze.getName());
                    }
                    writeEntry(zipFile, zos, ze);
                }
            }
        } catch (java.io.IOException ioe) {
            error(rb.getString("unable.to.sign.jar.") + ioe, ioe);
        } finally {
            // close the resouces
            if (zipFile != null) {
                zipFile.close();
                zipFile = null;
            }

            if (zos != null) {
                zos.close();
            }
        }

        // no IOException thrown in the follow try clause, so disable
        // the try clause.
        // try {
        if (signedjar == null) {
            // attempt an atomic rename. If that fails,
            // rename the original jar file, then the signed
            // one, then delete the original.
            if (!signedJarFile.renameTo(jarFile)) {
                java.io.File origJar = new java.io.File(jarName + ".orig");

                if (jarFile.renameTo(origJar)) {
                    if (signedJarFile.renameTo(jarFile)) {
                        origJar.delete();
                    } else {
                        java.text.MessageFormat form = new java.text.MessageFormat(rb.getString
                                ("attempt.to.rename.signedJarFile.to.jarFile.failed"));
                        Object[] source = {signedJarFile, jarFile};
                        error(form.format(source));
                    }
                } else {
                    java.text.MessageFormat form = new java.text.MessageFormat(rb.getString
                            ("attempt.to.rename.jarFile.to.origJar.failed"));
                    Object[] source = {jarFile, origJar};
                    error(form.format(source));
                }
            }
        }

        boolean warningAppeared = false;
        if (badKeyUsage || badExtendedKeyUsage || badNetscapeCertType ||
                notYetValidCert || chainNotValidated || hasExpiredCert) {
            if (strict) {
                System.out.println(rb.getString("jar.signed.with.signer.errors."));
                System.out.println();
                System.out.println(rb.getString("Error."));
            } else {
                System.out.println(rb.getString("jar.signed."));
                System.out.println();
                System.out.println(rb.getString("Warning."));
                warningAppeared = true;
            }

            if (badKeyUsage) {
                System.out.println(
                        rb.getString("The.signer.certificate.s.KeyUsage.extension.doesn.t.allow.code.signing."));
            }

            if (badExtendedKeyUsage) {
                System.out.println(
                        rb.getString("The.signer.certificate.s.ExtendedKeyUsage.extension.doesn.t.allow.code.signing."));
            }

            if (badNetscapeCertType) {
                System.out.println(
                        rb.getString("The.signer.certificate.s.NetscapeCertType.extension.doesn.t.allow.code.signing."));
            }

            if (hasExpiredCert) {
                System.out.println(
                        rb.getString("The.signer.certificate.has.expired."));
            } else if (notYetValidCert) {
                System.out.println(
                        rb.getString("The.signer.certificate.is.not.yet.valid."));
            }

            if (chainNotValidated) {
                System.out.println(
                        rb.getString("The.signer.s.certificate.chain.is.not.validated."));
            }
        } else {
            System.out.println(rb.getString("jar.signed."));
        }
        if (hasExpiringCert || noTimestamp) {
            if (!warningAppeared) {
                System.out.println();
                System.out.println(rb.getString("Warning."));
            }

            if (hasExpiringCert) {
                System.out.println(
                        rb.getString("The.signer.certificate.will.expire.within.six.months."));
            }

            if (noTimestamp) {
                System.out.println(
                        String.format(rb.getString("no.timestamp.signing"), expireDate));
            }
        }

        // no IOException thrown in the above try clause, so disable
        // the catch clause.
        // } catch(IOException ioe) {
        //     error(rb.getString("unable.to.sign.jar.")+ioe, ioe);
        // }
    }

    /**
     * signature-related files include:
     * . META-INF/MANIFEST.MF
     * . META-INF/SIG-*
     * . META-INF/*.SF
     * . META-INF/*.DSA
     * . META-INF/*.RSA
     * . META-INF/*.EC
     */
    private boolean signatureRelated(String name) {
        return SignatureFileVerifier.isSigningRelated(name);
    }

    /**
     * Returns a string of singer info, with a newline at the end
     */
    private String signerInfo(java.security.CodeSigner signer, String tab) {
        if (cacheForSignerInfo.containsKey(signer)) {
            return cacheForSignerInfo.get(signer);
        }
        StringBuffer s = new StringBuffer();
        java.util.List<? extends java.security.cert.Certificate> certs = signer.getSignerCertPath().getCertificates();
        // display the signature timestamp, if present
        java.util.Date timestamp;
        java.security.Timestamp ts = signer.getTimestamp();
        if (ts != null) {
            s.append(printTimestamp(tab, ts));
            s.append('\n');
            timestamp = ts.getTimestamp();
        } else {
            timestamp = null;
            noTimestamp = true;
        }
        // display the certificate(s). The first one is end-entity cert and
        // its KeyUsage should be checked.
        boolean first = true;
        for (java.security.cert.Certificate c : certs) {
            s.append(printCert(tab, c, true, timestamp, first));
            s.append('\n');
            first = false;
        }
        try {
            validateCertChain(certs);
        } catch (Exception e) {
            if (debug) {
                e.printStackTrace();
            }
            if (e.getCause() != null &&
                    (e.getCause() instanceof java.security.cert.CertificateExpiredException ||
                            e.getCause() instanceof java.security.cert.CertificateNotYetValidException)) {
                // No more warning, we alreay have hasExpiredCert or notYetValidCert
            } else {
                chainNotValidated = true;
                s.append(tab + rb.getString(".CertPath.not.validated.") +
                        e.getLocalizedMessage() + "]\n");   // TODO
            }
        }
        String result = s.toString();
        cacheForSignerInfo.put(signer, result);
        return result;
    }

    /*
     * Updates the digest attributes of a manifest entry, by adding or
     * replacing digest values.
     * A digest value is added if the manifest entry does not contain a digest
     * for that particular algorithm.
     * A digest value is replaced if it is obsolete.
     *
     * Returns true if the manifest entry has been changed, and false
     * otherwise.
     */
    private boolean updateDigests(java.util.zip.ZipEntry ze, java.util.zip.ZipFile zf,
                                  java.security.MessageDigest[] digests,
                                  java.util.jar.Manifest mf) throws java.io.IOException {
        boolean update = false;

        java.util.jar.Attributes attrs = mf.getAttributes(ze.getName());
        String[] base64Digests = getDigests(ze, zf, digests);

        for (int i = 0; i < digests.length; i++) {
            // The entry name to be written into attrs
            String name = null;
            try {
                // Find if the digest already exists
                AlgorithmId aid = AlgorithmId.get(digests[i].getAlgorithm());
                for (Object key : attrs.keySet()) {
                    if (key instanceof java.util.jar.Attributes.Name) {
                        String n = ((java.util.jar.Attributes.Name) key).toString();
                        if (n.toUpperCase(java.util.Locale.ENGLISH).endsWith("-DIGEST")) {
                            String tmp = n.substring(0, n.length() - 7);
                            if (AlgorithmId.get(tmp).equals(aid)) {
                                name = n;
                                break;
                            }
                        }
                    }
                }
            } catch (java.security.NoSuchAlgorithmException nsae) {
                // Ignored. Writing new digest entry.
            }

            if (name == null) {
                name = digests[i].getAlgorithm() + "-Digest";
                attrs.putValue(name, base64Digests[i]);
                update = true;
            } else {
                // compare digests, and replace the one in the manifest
                // if they are different
                String mfDigest = attrs.getValue(name);
                if (!mfDigest.equalsIgnoreCase(base64Digests[i])) {
                    attrs.putValue(name, base64Digests[i]);
                    update = true;
                }
            }
        }
        return update;
    }

    void validateCertChain(java.util.List<? extends java.security.cert.Certificate> certs) throws Exception {
        int cpLen = 0;
        out:
        for (; cpLen < certs.size(); cpLen++) {
            for (java.security.cert.TrustAnchor ta : pkixParameters.getTrustAnchors()) {
                if (ta.getTrustedCert().equals(certs.get(cpLen))) {
                    break out;
                }
            }
        }
        if (cpLen > 0) {
            java.security.cert.CertPath cp = certificateFactory.generateCertPath(
                    (cpLen == certs.size()) ? certs : certs.subList(0, cpLen));
            validator.validate(cp, pkixParameters);
        }
    }

    void verifyJar(String jarName)
            throws Exception {
        boolean anySigned = false;  // if there exists entry inside jar signed
        java.util.jar.JarFile jf = null;

        try {
            jf = new java.util.jar.JarFile(jarName, true);
            java.util.Vector<java.util.jar.JarEntry> entriesVec = new java.util.Vector<>();
            byte[] buffer = new byte[8192];

            java.util.Enumeration<java.util.jar.JarEntry> entries = jf.entries();
            while (entries.hasMoreElements()) {
                java.util.jar.JarEntry je = entries.nextElement();
                entriesVec.addElement(je);
                java.io.InputStream is = null;
                try {
                    is = jf.getInputStream(je);
                    int n;
                    while ((n = is.read(buffer, 0, buffer.length)) != -1) {
                        // we just read. this will throw a SecurityException
                        // if  a signature/digest check fails.
                    }
                } finally {
                    if (is != null) {
                        is.close();
                    }
                }
            }

            java.util.jar.Manifest man = jf.getManifest();

            // The map to record display info, only used when -verbose provided
            //      key: signer info string
            //      value: the list of files with common key
            java.util.Map<String, java.util.List<String>> output = new java.util.LinkedHashMap<>();

            if (man != null) {
                if (verbose != null) System.out.println();
                java.util.Enumeration<java.util.jar.JarEntry> e = entriesVec.elements();

                String tab = rb.getString("6SPACE");

                while (e.hasMoreElements()) {
                    java.util.jar.JarEntry je = e.nextElement();
                    String name = je.getName();
                    java.security.CodeSigner[] signers = je.getCodeSigners();
                    boolean isSigned = (signers != null);
                    anySigned |= isSigned;
                    hasUnsignedEntry |= !je.isDirectory() && !isSigned
                            && !signatureRelated(name);

                    int inStoreOrScope = inKeyStore(signers);

                    boolean inStore = (inStoreOrScope & IN_KEYSTORE) != 0;
                    boolean inScope = (inStoreOrScope & IN_SCOPE) != 0;

                    notSignedByAlias |= (inStoreOrScope & NOT_ALIAS) != 0;
                    if (keystore != null) {
                        aliasNotInStore |= isSigned && (!inStore && !inScope);
                    }

                    // Only used when -verbose provided
                    StringBuffer sb = null;
                    if (verbose != null) {
                        sb = new StringBuffer();
                        boolean inManifest =
                                ((man.getAttributes(name) != null) ||
                                        (man.getAttributes("./" + name) != null) ||
                                        (man.getAttributes("/" + name) != null));
                        sb.append(
                                (isSigned ? rb.getString("s") : rb.getString("SPACE")) +
                                        (inManifest ? rb.getString("m") : rb.getString("SPACE")) +
                                        (inStore ? rb.getString("k") : rb.getString("SPACE")) +
                                        (inScope ? rb.getString("i") : rb.getString("SPACE")) +
                                        ((inStoreOrScope & NOT_ALIAS) != 0 ? "X" : " ") +
                                        rb.getString("SPACE"));
                        sb.append("|");
                    }

                    // When -certs provided, display info has extra empty
                    // lines at the beginning and end.
                    if (isSigned) {
                        if (showcerts) sb.append('\n');
                        for (java.security.CodeSigner signer : signers) {
                            // signerInfo() must be called even if -verbose
                            // not provided. The method updates various
                            // warning flags.
                            String si = signerInfo(signer, tab);
                            if (showcerts) {
                                sb.append(si);
                                sb.append('\n');
                            }
                        }
                    } else if (showcerts && !verbose.equals("all")) {
                        // Print no info for unsigned entries when -verbose:all,
                        // to be consistent with old behavior.
                        if (signatureRelated(name)) {
                            sb.append("\n" + tab + rb.getString(
                                    ".Signature.related.entries.") + "\n\n");
                        } else {
                            sb.append("\n" + tab + rb.getString(
                                    ".Unsigned.entries.") + "\n\n");
                        }
                    }

                    if (verbose != null) {
                        String label = sb.toString();
                        if (signatureRelated(name)) {
                            // Entries inside META-INF and other unsigned
                            // entries are grouped separately.
                            label = "-" + label;
                        }

                        // The label finally contains 2 parts separated by '|':
                        // The legend displayed before the entry names, and
                        // the cert info (if -certs specified).

                        if (!output.containsKey(label)) {
                            output.put(label, new java.util.ArrayList<String>());
                        }

                        StringBuffer fb = new StringBuffer();
                        String s = Long.toString(je.getSize());
                        for (int i = 6 - s.length(); i > 0; --i) {
                            fb.append(' ');
                        }
                        fb.append(s).append(' ').
                                append(new java.util.Date(je.getTime()).toString());
                        fb.append(' ').append(name);

                        output.get(label).add(fb.toString());
                    }
                }
            }
            if (verbose != null) {
                for (java.util.Map.Entry<String, java.util.List<String>> s : output.entrySet()) {
                    java.util.List<String> files = s.getValue();
                    String key = s.getKey();
                    if (key.charAt(0) == '-') { // the signature-related group
                        key = key.substring(1);
                    }
                    int pipe = key.indexOf('|');
                    if (verbose.equals("all")) {
                        for (String f : files) {
                            System.out.println(key.substring(0, pipe) + f);
                            System.out.printf(key.substring(pipe + 1));
                        }
                    } else {
                        if (verbose.equals("grouped")) {
                            for (String f : files) {
                                System.out.println(key.substring(0, pipe) + f);
                            }
                        } else if (verbose.equals("summary")) {
                            System.out.print(key.substring(0, pipe));
                            if (files.size() > 1) {
                                System.out.println(files.get(0) + " " +
                                        String.format(rb.getString(
                                                ".and.d.more."), files.size() - 1));
                            } else {
                                System.out.println(files.get(0));
                            }
                        }
                        System.out.printf(key.substring(pipe + 1));
                    }
                }
                System.out.println();
                System.out.println(rb.getString(
                        ".s.signature.was.verified."));
                System.out.println(rb.getString(
                        ".m.entry.is.listed.in.manifest"));
                System.out.println(rb.getString(
                        ".k.at.least.one.certificate.was.found.in.keystore"));
                System.out.println(rb.getString(
                        ".i.at.least.one.certificate.was.found.in.identity.scope"));
                if (ckaliases.size() > 0) {
                    System.out.println(rb.getString(
                            ".X.not.signed.by.specified.alias.es."));
                }
                System.out.println();
            }
            if (man == null)
                System.out.println(rb.getString("no.manifest."));

            if (!anySigned) {
                System.out.println(rb.getString(
                        "jar.is.unsigned.signatures.missing.or.not.parsable."));
            } else {
                boolean warningAppeared = false;
                boolean errorAppeared = false;
                if (badKeyUsage || badExtendedKeyUsage || badNetscapeCertType ||
                        notYetValidCert || chainNotValidated || hasExpiredCert ||
                        hasUnsignedEntry ||
                        aliasNotInStore || notSignedByAlias) {

                    if (strict) {
                        System.out.println(rb.getString("jar.verified.with.signer.errors."));
                        System.out.println();
                        System.out.println(rb.getString("Error."));
                        errorAppeared = true;
                    } else {
                        System.out.println(rb.getString("jar.verified."));
                        System.out.println();
                        System.out.println(rb.getString("Warning."));
                        warningAppeared = true;
                    }

                    if (badKeyUsage) {
                        System.out.println(
                                rb.getString("This.jar.contains.entries.whose.signer.certificate.s.KeyUsage.extension.doesn.t.allow.code.signing."));
                    }

                    if (badExtendedKeyUsage) {
                        System.out.println(
                                rb.getString("This.jar.contains.entries.whose.signer.certificate.s.ExtendedKeyUsage.extension.doesn.t.allow.code.signing."));
                    }

                    if (badNetscapeCertType) {
                        System.out.println(
                                rb.getString("This.jar.contains.entries.whose.signer.certificate.s.NetscapeCertType.extension.doesn.t.allow.code.signing."));
                    }

                    if (hasUnsignedEntry) {
                        System.out.println(rb.getString(
                                "This.jar.contains.unsigned.entries.which.have.not.been.integrity.checked."));
                    }
                    if (hasExpiredCert) {
                        System.out.println(rb.getString(
                                "This.jar.contains.entries.whose.signer.certificate.has.expired."));
                    }
                    if (notYetValidCert) {
                        System.out.println(rb.getString(
                                "This.jar.contains.entries.whose.signer.certificate.is.not.yet.valid."));
                    }

                    if (chainNotValidated) {
                        System.out.println(
                                rb.getString("This.jar.contains.entries.whose.certificate.chain.is.not.validated."));
                    }

                    if (notSignedByAlias) {
                        System.out.println(
                                rb.getString("This.jar.contains.signed.entries.which.is.not.signed.by.the.specified.alias.es."));
                    }

                    if (aliasNotInStore) {
                        System.out.println(rb.getString("This.jar.contains.signed.entries.that.s.not.signed.by.alias.in.this.keystore."));
                    }
                } else {
                    System.out.println(rb.getString("jar.verified."));
                }
                if (hasExpiringCert || noTimestamp) {
                    if (!warningAppeared) {
                        System.out.println();
                        System.out.println(rb.getString("Warning."));
                        warningAppeared = true;
                    }
                    if (hasExpiringCert) {
                        System.out.println(rb.getString(
                                "This.jar.contains.entries.whose.signer.certificate.will.expire.within.six.months."));
                    }
                    if (noTimestamp) {
                        System.out.println(
                                String.format(rb.getString("no.timestamp.verifying"), expireDate));
                    }
                }
                if (warningAppeared || errorAppeared) {
                    if (!(verbose != null && showcerts)) {
                        System.out.println();
                        System.out.println(rb.getString(
                                "Re.run.with.the.verbose.and.certs.options.for.more.details."));
                    }
                }
            }
            return;
        } catch (Exception e) {
            System.out.println(rb.getString("jarsigner.") + e);
            if (debug) {
                e.printStackTrace();
            }
        } finally { // close the resource
            if (jf != null) {
                jf.close();
            }
        }

        System.exit(1);
    }

    /**
     * Writes all the bytes for a given entry to the specified output stream.
     */
    private synchronized void writeBytes
    (java.util.zip.ZipFile zf, java.util.zip.ZipEntry ze, java.util.zip.ZipOutputStream os) throws java.io.IOException {
        int n;

        java.io.InputStream is = null;
        try {
            is = zf.getInputStream(ze);
            long left = ze.getSize();

            while ((left > 0) && (n = is.read(buffer, 0, buffer.length)) != -1) {
                os.write(buffer, 0, n);
                left -= n;
            }
        } finally {
            if (is != null) {
                is.close();
            }
        }
    }

    private void writeEntry(java.util.zip.ZipFile zf, java.util.zip.ZipOutputStream os, java.util.zip.ZipEntry ze)
            throws java.io.IOException {
        java.util.zip.ZipEntry ze2 = new java.util.zip.ZipEntry(ze.getName());
        ze2.setMethod(ze.getMethod());
        ze2.setTime(ze.getTime());
        ze2.setComment(ze.getComment());
        ze2.setExtra(ze.getExtra());
        if (ze.getMethod() == java.util.zip.ZipEntry.STORED) {
            ze2.setSize(ze.getSize());
            ze2.setCrc(ze.getCrc());
        }
        os.putNextEntry(ze2);
        writeBytes(zf, ze, os);
    }
}

class SignatureFile {

    /**
     * .SF base name
     */
    String baseName;
    /**
     * SignatureFile
     */
    java.util.jar.Manifest sf;

    public SignatureFile(java.security.MessageDigest digests[],
                         java.util.jar.Manifest mf,
                         ManifestDigester md,
                         String baseName,
                         boolean signManifest) {
        this.baseName = baseName;

        String version = System.getProperty("java.version");
        String javaVendor = System.getProperty("java.vendor");

        sf = new java.util.jar.Manifest();
        java.util.jar.Attributes mattr = sf.getMainAttributes();

        mattr.putValue(java.util.jar.Attributes.Name.SIGNATURE_VERSION.toString(), "1.0");
        mattr.putValue("Created-By", version + " (" + javaVendor + ")");

        if (signManifest) {
            // sign the whole manifest
            for (int i = 0; i < digests.length; i++) {
                mattr.putValue(digests[i].getAlgorithm() + "-Digest-Manifest",
                        java.util.Base64.getEncoder().encodeToString(md.manifestDigest(digests[i])));
            }
        }

        // create digest of the manifest main attributes
        ManifestDigester.Entry mde =
                md.get(ManifestDigester.MF_MAIN_ATTRS, false);
        if (mde != null) {
            for (int i = 0; i < digests.length; i++) {
                mattr.putValue(digests[i].getAlgorithm() +
                                "-Digest-" + ManifestDigester.MF_MAIN_ATTRS,
                        java.util.Base64.getEncoder().encodeToString(mde.digest(digests[i])));
            }
        } else {
            throw new IllegalStateException
                    ("ManifestDigester failed to create " +
                            "Manifest-Main-Attribute entry");
        }

        /* go through the manifest entries and create the digests */

        java.util.Map<String, java.util.jar.Attributes> entries = sf.getEntries();
        java.util.Iterator<java.util.Map.Entry<String, java.util.jar.Attributes>> mit =
                mf.getEntries().entrySet().iterator();
        while (mit.hasNext()) {
            java.util.Map.Entry<String, java.util.jar.Attributes> e = mit.next();
            String name = e.getKey();
            mde = md.get(name, false);
            if (mde != null) {
                java.util.jar.Attributes attr = new java.util.jar.Attributes();
                for (int i = 0; i < digests.length; i++) {
                    attr.putValue(digests[i].getAlgorithm() + "-Digest",
                            java.util.Base64.getEncoder().encodeToString(mde.digest(digests[i])));
                }
                entries.put(name, attr);
            }
        }
    }

    /*
     * Generate a signed data block.
     * If a URL or a certificate (containing a URL) for a Timestamping
     * Authority is supplied then a signature timestamp is generated and
     * inserted into the signed data block.
     *
     * @param sigalg signature algorithm to use, or null to use default
     * @param tsaUrl The location of the Timestamping Authority. If null
     *               then no timestamp is requested.
     * @param tsaCert The certificate for the Timestamping Authority. If null
     *               then no timestamp is requested.
     * @param signingMechanism The signing mechanism to use.
     * @param args The command-line arguments to jarsigner.
     * @param zipFile The original source Zip file.
     */
    public Block generateBlock(java.security.PrivateKey privateKey,
                               String sigalg,
                               java.security.cert.X509Certificate[] certChain,
                               boolean externalSF, String tsaUrl,
                               java.security.cert.X509Certificate tsaCert,
                               String tSAPolicyID,
                               ContentSigner signingMechanism,
                               String[] args, java.util.zip.ZipFile zipFile)
            throws java.security.NoSuchAlgorithmException, java.security.InvalidKeyException, java.io.IOException,
            java.security.SignatureException, java.security.cert.CertificateException {
        return new Block(this, privateKey, sigalg, certChain, externalSF,
                tsaUrl, tsaCert, tSAPolicyID, signingMechanism, args, zipFile);
    }

    /**
     * get base file name
     */
    public String getBaseName() {
        return baseName;
    }

    /**
     * get .SF file name
     */
    public String getMetaName() {
        return "META-INF/" + baseName + ".SF";
    }

    /**
     * Writes the SignatureFile to the specified OutputStream.
     *
     * @param out the output stream
     * @throws IOException if an I/O error has occurred
     */

    public void write(java.io.OutputStream out) throws java.io.IOException {
        sf.write(out);
    }

    public static class Block {

        private byte[] block;
        private String blockFileName;

        /*
         * Construct a new signature block.
         */
        Block(SignatureFile sfg, java.security.PrivateKey privateKey, String sigalg,
              java.security.cert.X509Certificate[] certChain, boolean externalSF, String tsaUrl,
              java.security.cert.X509Certificate tsaCert, String tSAPolicyID, ContentSigner signingMechanism,
              String[] args, java.util.zip.ZipFile zipFile)
                throws java.security.NoSuchAlgorithmException, java.security.InvalidKeyException, java.io.IOException,
                java.security.SignatureException, java.security.cert.CertificateException {

            java.security.Principal issuerName = certChain[0].getIssuerDN();
            if (!(issuerName instanceof X500Name)) {
                // must extract the original encoded form of DN for subsequent
                // name comparison checks (converting to a String and back to
                // an encoded DN could cause the types of String attribute
                // values to be changed)
                X509CertInfo tbsCert = new
                        X509CertInfo(certChain[0].getTBSCertificate());
                issuerName = (java.security.Principal)
                        tbsCert.get(X509CertInfo.ISSUER + "." +
                                X509CertInfo.DN_NAME);
            }
            java.math.BigInteger serial = certChain[0].getSerialNumber();

            String signatureAlgorithm;
            String keyAlgorithm = privateKey.getAlgorithm();
            /*
             * If no signature algorithm was specified, we choose a
             * default that is compatible with the private key algorithm.
             */
            if (sigalg == null) {

                if (keyAlgorithm.equalsIgnoreCase("DSA"))
                    signatureAlgorithm = "SHA1withDSA";
                else if (keyAlgorithm.equalsIgnoreCase("RSA"))
                    signatureAlgorithm = "SHA256withRSA";
                else if (keyAlgorithm.equalsIgnoreCase("EC"))
                    signatureAlgorithm = "SHA256withECDSA";
                else
                    throw new RuntimeException("private key is not a DSA or "
                            + "RSA key");
            } else {
                signatureAlgorithm = sigalg;
            }

            // check common invalid key/signature algorithm combinations
            String sigAlgUpperCase = signatureAlgorithm.toUpperCase(java.util.Locale.ENGLISH);
            if ((sigAlgUpperCase.endsWith("WITHRSA") &&
                    !keyAlgorithm.equalsIgnoreCase("RSA")) ||
                    (sigAlgUpperCase.endsWith("WITHECDSA") &&
                            !keyAlgorithm.equalsIgnoreCase("EC")) ||
                    (sigAlgUpperCase.endsWith("WITHDSA") &&
                            !keyAlgorithm.equalsIgnoreCase("DSA"))) {
                throw new java.security.SignatureException
                        ("private key algorithm is not compatible with signature algorithm");
            }

            blockFileName = "META-INF/" + sfg.getBaseName() + "." + keyAlgorithm;

            AlgorithmId sigAlg = AlgorithmId.get(signatureAlgorithm);
            AlgorithmId digEncrAlg = AlgorithmId.get(keyAlgorithm);

            java.security.Signature sig = java.security.Signature.getInstance(signatureAlgorithm);
            sig.initSign(privateKey);

            java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
            sfg.write(baos);

            byte[] content = baos.toByteArray();

            sig.update(content);
            byte[] signature = sig.sign();

            // Timestamp the signature and generate the signature block file
            if (signingMechanism == null) {
                signingMechanism = new TimestampedSigner();
            }
            java.net.URI tsaUri = null;
            try {
                if (tsaUrl != null) {
                    tsaUri = new java.net.URI(tsaUrl);
                }
            } catch (java.net.URISyntaxException e) {
                throw new java.io.IOException(e);
            }

            // Assemble parameters for the signing mechanism
            ContentSignerParameters params =
                    new JarSignerParameters(args, tsaUri, tsaCert, tSAPolicyID, signature,
                            signatureAlgorithm, certChain, content, zipFile);

            // Generate the signature block
            block = signingMechanism.generateSignedData(
                    params, externalSF, (tsaUrl != null || tsaCert != null));
        }

        /*
         * get block file name.
         */
        public String getMetaName() {
            return blockFileName;
        }

        /**
         * Writes the block file to the specified OutputStream.
         *
         * @param out the output stream
         * @throws IOException if an I/O error has occurred
         */

        public void write(java.io.OutputStream out) throws java.io.IOException {
            out.write(block);
        }
    }
}
