/*
 * Copyright (c) 2006, 2013, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package de.ing.security.util;

import de.ing.security.x509.X509Key;

public class ECUtil {

    private ECUtil() {
    }

    public static java.security.interfaces.ECPrivateKey decodePKCS8ECPrivateKey(byte[] encoded)
            throws java.security.spec.InvalidKeySpecException {
        java.security.KeyFactory keyFactory = getKeyFactory();
        java.security.spec.PKCS8EncodedKeySpec keySpec = new java.security.spec.PKCS8EncodedKeySpec(encoded);

        return (java.security.interfaces.ECPrivateKey) keyFactory.generatePrivate(keySpec);
    }

    // Used by SunPKCS11 and SunJSSE.
    public static java.security.spec.ECPoint decodePoint(byte[] data, java.security.spec.EllipticCurve curve)
            throws java.io.IOException {
        if ((data.length == 0) || (data[0] != 4)) {
            throw new java.io.IOException("Only uncompressed point format supported");
        }
        // Per ANSI X9.62, an encoded point is a 1 byte type followed by
        // ceiling(log base 2 field-size / 8) bytes of x and the same of y.
        int n = (data.length - 1) / 2;
        if (n != ((curve.getField().getFieldSize() + 7) >> 3)) {
            throw new java.io.IOException("Point does not match field size");
        }

        byte[] xb = java.util.Arrays.copyOfRange(data, 1, 1 + n);
        byte[] yb = java.util.Arrays.copyOfRange(data, n + 1, n + 1 + n);

        return new java.security.spec.ECPoint(new java.math.BigInteger(1, xb), new java.math.BigInteger(1, yb));
    }

    public static java.security.interfaces.ECPublicKey decodeX509ECPublicKey(byte[] encoded)
            throws java.security.spec.InvalidKeySpecException {
        java.security.KeyFactory keyFactory = getKeyFactory();
        java.security.spec.X509EncodedKeySpec keySpec = new java.security.spec.X509EncodedKeySpec(encoded);

        return (java.security.interfaces.ECPublicKey) keyFactory.generatePublic(keySpec);
    }

    public static byte[] encodeECParameterSpec(java.security.Provider p,
                                               java.security.spec.ECParameterSpec spec) {
        java.security.AlgorithmParameters parameters = getECParameters(p);

        try {
            parameters.init(spec);
        } catch (java.security.spec.InvalidParameterSpecException ipse) {
            throw new RuntimeException("Not a known named curve: " + spec);
        }

        try {
            return parameters.getEncoded();
        } catch (java.io.IOException ioe) {
            // it is a bug if this should happen
            throw new RuntimeException(ioe);
        }
    }

    // Used by SunPKCS11 and SunJSSE.
    public static byte[] encodePoint(java.security.spec.ECPoint point, java.security.spec.EllipticCurve curve) {
        // get field size in bytes (rounding up)
        int n = (curve.getField().getFieldSize() + 7) >> 3;
        byte[] xb = trimZeroes(point.getAffineX().toByteArray());
        byte[] yb = trimZeroes(point.getAffineY().toByteArray());
        if ((xb.length > n) || (yb.length > n)) {
            throw new RuntimeException
                    ("Point coordinates do not match field size");
        }
        byte[] b = new byte[1 + (n << 1)];
        b[0] = 4; // uncompressed
        System.arraycopy(xb, 0, b, n - xb.length + 1, xb.length);
        System.arraycopy(yb, 0, b, b.length - yb.length, yb.length);
        return b;
    }

    public static java.security.interfaces.ECPrivateKey generateECPrivateKey(java.math.BigInteger s,
                                                                             java.security.spec.ECParameterSpec params) throws java.security.spec.InvalidKeySpecException {
        java.security.KeyFactory keyFactory = getKeyFactory();
        java.security.spec.ECPrivateKeySpec keySpec = new java.security.spec.ECPrivateKeySpec(s, params);

        return (java.security.interfaces.ECPrivateKey) keyFactory.generatePrivate(keySpec);
    }

    public static String getCurveName(java.security.Provider p, java.security.spec.ECParameterSpec spec) {
        java.security.spec.ECGenParameterSpec nameSpec;
        java.security.AlgorithmParameters parameters = getECParameters(p);

        try {
            parameters.init(spec);
            nameSpec = parameters.getParameterSpec(java.security.spec.ECGenParameterSpec.class);
        } catch (java.security.spec.InvalidParameterSpecException ipse) {
            return null;
        }

        if (nameSpec == null) {
            return null;
        }

        return nameSpec.getName();
    }

    public static java.security.spec.ECParameterSpec getECParameterSpec(java.security.Provider p,
                                                                        java.security.spec.ECParameterSpec spec) {
        java.security.AlgorithmParameters parameters = getECParameters(p);

        try {
            parameters.init(spec);
            return parameters.getParameterSpec(java.security.spec.ECParameterSpec.class);
        } catch (java.security.spec.InvalidParameterSpecException ipse) {
            return null;
        }
    }

    public static java.security.spec.ECParameterSpec getECParameterSpec(java.security.Provider p,
                                                                        byte[] params)
            throws java.io.IOException {
        java.security.AlgorithmParameters parameters = getECParameters(p);

        parameters.init(params);

        try {
            return parameters.getParameterSpec(java.security.spec.ECParameterSpec.class);
        } catch (java.security.spec.InvalidParameterSpecException ipse) {
            return null;
        }
    }

    public static java.security.spec.ECParameterSpec getECParameterSpec(java.security.Provider p, String name) {
        java.security.AlgorithmParameters parameters = getECParameters(p);

        try {
            parameters.init(new java.security.spec.ECGenParameterSpec(name));
            return parameters.getParameterSpec(java.security.spec.ECParameterSpec.class);
        } catch (java.security.spec.InvalidParameterSpecException ipse) {
            return null;
        }
    }

    public static java.security.spec.ECParameterSpec getECParameterSpec(java.security.Provider p, int keySize) {
        java.security.AlgorithmParameters parameters = getECParameters(p);

        try {
            parameters.init(new ECKeySizeParameterSpec(keySize));
            return parameters.getParameterSpec(java.security.spec.ECParameterSpec.class);
        } catch (java.security.spec.InvalidParameterSpecException ipse) {
            return null;
        }

    }

    private static java.security.AlgorithmParameters getECParameters(java.security.Provider p) {
        try {
            if (p != null) {
                return java.security.AlgorithmParameters.getInstance("EC", p);
            }

            return java.security.AlgorithmParameters.getInstance("EC");
        } catch (java.security.NoSuchAlgorithmException nsae) {
            throw new RuntimeException(nsae);
        }
    }

    private static java.security.KeyFactory getKeyFactory() {
        try {
            return java.security.KeyFactory.getInstance("EC", "SunEC");
        } catch (java.security.NoSuchAlgorithmException | java.security.NoSuchProviderException e) {
            throw new RuntimeException(e);
        }
    }

    public static byte[] trimZeroes(byte[] b) {
        int i = 0;
        while ((i < b.length - 1) && (b[i] == 0)) {
            i++;
        }
        if (i == 0) {
            return b;
        }

        return java.util.Arrays.copyOfRange(b, i, b.length);
    }

    public static byte[] x509EncodeECPublicKey(java.security.spec.ECPoint w,
                                               java.security.spec.ECParameterSpec params) throws java.security.spec.InvalidKeySpecException {
        java.security.KeyFactory keyFactory = getKeyFactory();
        java.security.spec.ECPublicKeySpec keySpec = new java.security.spec.ECPublicKeySpec(w, params);
        X509Key key = (X509Key) keyFactory.generatePublic(keySpec);

        return key.getEncoded();
    }
}
