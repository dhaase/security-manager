/*
 * Copyright (c) 1997, 2011, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package de.ing.security.x509;

import de.ing.security.util.DerInputStream;
import de.ing.security.util.DerOutputStream;
import de.ing.security.util.DerValue;

import java.io.IOException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateNotYetValidException;

/**
 * This class defines the Private Key Usage Extension.
 *
 * <p>The Private Key Usage Period extension allows the certificate issuer
 * to specify a different validity period for the private key than the
 * certificate. This extension is intended for use with digital
 * signature keys.  This extension consists of two optional components
 * notBefore and notAfter.  The private key associated with the
 * certificate should not be used to sign objects before or after the
 * times specified by the two components, respectively.
 *
 * <pre>
 * PrivateKeyUsagePeriod ::= SEQUENCE {
 *     notBefore  [0]  GeneralizedTime OPTIONAL,
 *     notAfter   [1]  GeneralizedTime OPTIONAL }
 * </pre>
 *
 * @author Amit Kapoor
 * @author Hemma Prafullchandra
 * @see Extension
 * @see CertAttrSet
 */
public class PrivateKeyUsageExtension extends Extension
        implements CertAttrSet<String> {
    /**
     * Identifier for this attribute, to be used with the
     * get, set, delete methods of Certificate, x509 type.
     */
    public static final String IDENT = "x509.info.extensions.PrivateKeyUsage";
    /**
     * Sub attributes name for this CertAttrSet.
     */
    public static final String NAME = "PrivateKeyUsage";
    public static final String NOT_AFTER = "not_after";
    public static final String NOT_BEFORE = "not_before";
    private static final byte TAG_AFTER = 1;
    // Private data members
    private static final byte TAG_BEFORE = 0;
    private java.util.Date notAfter = null;
    private java.util.Date notBefore = null;

    /**
     * The default constructor for PrivateKeyUsageExtension.
     *
     * @param notBefore the date/time before which the private key
     *                  should not be used.
     * @param notAfter  the date/time after which the private key
     *                  should not be used.
     */
    public PrivateKeyUsageExtension(java.util.Date notBefore, java.util.Date notAfter)
            throws java.io.IOException {
        this.notBefore = notBefore;
        this.notAfter = notAfter;

        this.extensionId = PKIXExtensions.PrivateKeyUsage_Id;
        this.critical = false;
        encodeThis();
    }

    /**
     * Create the extension from the passed DER encoded value.
     *
     * @param critical true if the extension is to be treated as critical.
     * @param value    an array of DER encoded bytes of the actual value.
     * @throws ClassCastException   if value is not an array of bytes
     * @throws CertificateException on certificate parsing errors.
     * @throws IOException          on error.
     */
    public PrivateKeyUsageExtension(Boolean critical, Object value)
            throws java.security.cert.CertificateException, java.io.IOException {
        this.extensionId = PKIXExtensions.PrivateKeyUsage_Id;
        this.critical = critical.booleanValue();

        this.extensionValue = (byte[]) value;
        DerInputStream str = new DerInputStream(this.extensionValue);
        DerValue[] seq = str.getSequence(2);

        // NB. this is always encoded with the IMPLICIT tag
        // The checks only make sense if we assume implicit tagging,
        // with explicit tagging the form is always constructed.
        for (int i = 0; i < seq.length; i++) {
            DerValue opt = seq[i];

            if (opt.isContextSpecific(TAG_BEFORE) &&
                    !opt.isConstructed()) {
                if (notBefore != null) {
                    throw new java.security.cert.CertificateParsingException(
                            "Duplicate notBefore in PrivateKeyUsage.");
                }
                opt.resetTag(DerValue.tag_GeneralizedTime);
                str = new DerInputStream(opt.toByteArray());
                notBefore = str.getGeneralizedTime();

            } else if (opt.isContextSpecific(TAG_AFTER) &&
                    !opt.isConstructed()) {
                if (notAfter != null) {
                    throw new java.security.cert.CertificateParsingException(
                            "Duplicate notAfter in PrivateKeyUsage.");
                }
                opt.resetTag(DerValue.tag_GeneralizedTime);
                str = new DerInputStream(opt.toByteArray());
                notAfter = str.getGeneralizedTime();
            } else
                throw new java.io.IOException("Invalid encoding of " +
                        "PrivateKeyUsageExtension");
        }
    }

    /**
     * Delete the attribute value.
     *
     * @throws CertificateException on attribute handling errors.
     */
    public void delete(String name) throws java.security.cert.CertificateException, java.io.IOException {
        if (name.equalsIgnoreCase(NOT_BEFORE)) {
            notBefore = null;
        } else if (name.equalsIgnoreCase(NOT_AFTER)) {
            notAfter = null;
        } else {
            throw new java.security.cert.CertificateException("Attribute name not recognized by"
                    + " CertAttrSet:PrivateKeyUsage.");
        }
        encodeThis();
    }

    /**
     * Write the extension to the OutputStream.
     *
     * @param out the OutputStream to write the extension to.
     * @throws IOException on encoding errors.
     */
    public void encode(java.io.OutputStream out) throws java.io.IOException {
        DerOutputStream tmp = new DerOutputStream();
        if (extensionValue == null) {
            extensionId = PKIXExtensions.PrivateKeyUsage_Id;
            critical = false;
            encodeThis();
        }
        super.encode(tmp);
        out.write(tmp.toByteArray());
    }

    // Encode this extension value.
    private void encodeThis() throws java.io.IOException {
        if (notBefore == null && notAfter == null) {
            this.extensionValue = null;
            return;
        }
        DerOutputStream seq = new DerOutputStream();

        DerOutputStream tagged = new DerOutputStream();
        if (notBefore != null) {
            DerOutputStream tmp = new DerOutputStream();
            tmp.putGeneralizedTime(notBefore);
            tagged.writeImplicit(DerValue.createTag(DerValue.TAG_CONTEXT,
                    false, TAG_BEFORE), tmp);
        }
        if (notAfter != null) {
            DerOutputStream tmp = new DerOutputStream();
            tmp.putGeneralizedTime(notAfter);
            tagged.writeImplicit(DerValue.createTag(DerValue.TAG_CONTEXT,
                    false, TAG_AFTER), tmp);
        }
        seq.write(DerValue.tag_Sequence, tagged);
        this.extensionValue = seq.toByteArray();
    }

    /**
     * Get the attribute value.
     *
     * @throws CertificateException on attribute handling errors.
     */
    public java.util.Date get(String name) throws java.security.cert.CertificateException {
        if (name.equalsIgnoreCase(NOT_BEFORE)) {
            return (new java.util.Date(notBefore.getTime()));
        } else if (name.equalsIgnoreCase(NOT_AFTER)) {
            return (new java.util.Date(notAfter.getTime()));
        } else {
            throw new java.security.cert.CertificateException("Attribute name not recognized by"
                    + " CertAttrSet:PrivateKeyUsage.");
        }
    }

    /**
     * Return an enumeration of names of attributes existing within this
     * attribute.
     */
    public java.util.Enumeration<String> getElements() {
        AttributeNameEnumeration elements = new AttributeNameEnumeration();
        elements.addElement(NOT_BEFORE);
        elements.addElement(NOT_AFTER);

        return (elements.elements());
    }

    /**
     * Return the name of this attribute.
     */
    public String getName() {
        return (NAME);
    }

    /**
     * Set the attribute value.
     *
     * @throws CertificateException on attribute handling errors.
     */
    public void set(String name, Object obj)
            throws java.security.cert.CertificateException, java.io.IOException {
        if (!(obj instanceof java.util.Date)) {
            throw new java.security.cert.CertificateException("Attribute must be of type Date.");
        }
        if (name.equalsIgnoreCase(NOT_BEFORE)) {
            notBefore = (java.util.Date) obj;
        } else if (name.equalsIgnoreCase(NOT_AFTER)) {
            notAfter = (java.util.Date) obj;
        } else {
            throw new java.security.cert.CertificateException("Attribute name not recognized by"
                    + " CertAttrSet:PrivateKeyUsage.");
        }
        encodeThis();
    }

    /**
     * Return the printable string.
     */
    public String toString() {
        return (super.toString() +
                "PrivateKeyUsage: [\n" +
                ((notBefore == null) ? "" : "From: " + notBefore.toString() + ", ")
                + ((notAfter == null) ? "" : "To: " + notAfter.toString())
                + "]\n");
    }

    /**
     * Verify that that the current time is within the validity period.
     *
     * @throws CertificateExpiredException     if the certificate has expired.
     * @throws CertificateNotYetValidException if the certificate is not
     *                                         yet valid.
     */
    public void valid()
            throws java.security.cert.CertificateNotYetValidException, java.security.cert.CertificateExpiredException {
        java.util.Date now = new java.util.Date();
        valid(now);
    }

    /**
     * Verify that that the passed time is within the validity period.
     *
     * @throws CertificateExpiredException     if the certificate has expired
     *                                         with respect to the <code>Date</code> supplied.
     * @throws CertificateNotYetValidException if the certificate is not
     *                                         yet valid with respect to the <code>Date</code> supplied.
     */
    public void valid(java.util.Date now)
            throws java.security.cert.CertificateNotYetValidException, java.security.cert.CertificateExpiredException {
        /*
         * we use the internal Dates rather than the passed in Date
         * because someone could override the Date methods after()
         * and before() to do something entirely different.
         */
        if (notBefore.after(now)) {
            throw new java.security.cert.CertificateNotYetValidException("NotBefore: " +
                    notBefore.toString());
        }
        if (notAfter.before(now)) {
            throw new java.security.cert.CertificateExpiredException("NotAfter: " +
                    notAfter.toString());
        }
    }
}
