/*
 * Copyright (c) 1997, 2011, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package de.ing.security.x509;

import de.ing.security.util.Debug;
import de.ing.security.util.DerOutputStream;
import de.ing.security.util.DerValue;
import de.ing.security.util.ObjectIdentifier;

import java.io.IOException;

/**
 * Represent the CRL Number Extension.
 *
 * <p>This extension, if present, conveys a monotonically increasing
 * sequence number for each CRL issued by a given CA through a specific
 * CA X.500 Directory entry or CRL distribution point. This extension
 * allows users to easily determine when a particular CRL supersedes
 * another CRL.
 *
 * @author Hemma Prafullchandra
 * @see Extension
 * @see CertAttrSet
 */
public class CRLNumberExtension extends Extension
        implements CertAttrSet<String> {

    /**
     * Attribute name.
     */
    public static final String NAME = "CRLNumber";
    public static final String NUMBER = "value";

    private static final String LABEL = "CRL Number";

    private java.math.BigInteger crlNumber = null;
    private String extensionLabel;
    private String extensionName;

    /**
     * Create a CRLNumberExtension with the integer value .
     * The criticality is set to false.
     *
     * @param crlNum the value to be set for the extension.
     */
    public CRLNumberExtension(int crlNum) throws java.io.IOException {
        this(PKIXExtensions.CRLNumber_Id, false, java.math.BigInteger.valueOf(crlNum),
                NAME, LABEL);
    }

    /**
     * Create a CRLNumberExtension with the BigInteger value .
     * The criticality is set to false.
     *
     * @param crlNum the value to be set for the extension.
     */
    public CRLNumberExtension(java.math.BigInteger crlNum) throws java.io.IOException {
        this(PKIXExtensions.CRLNumber_Id, false, crlNum, NAME, LABEL);
    }

    /**
     * Creates the extension (also called by the subclass).
     */
    protected CRLNumberExtension(ObjectIdentifier extensionId,
                                 boolean isCritical, java.math.BigInteger crlNum, String extensionName,
                                 String extensionLabel) throws java.io.IOException {

        this.extensionId = extensionId;
        this.critical = isCritical;
        this.crlNumber = crlNum;
        this.extensionName = extensionName;
        this.extensionLabel = extensionLabel;
        encodeThis();
    }

    /**
     * Create the extension from the passed DER encoded value of the same.
     *
     * @param critical true if the extension is to be treated as critical.
     * @param value    an array of DER encoded bytes of the actual value.
     * @throws ClassCastException if value is not an array of bytes
     * @throws IOException        on error.
     */
    public CRLNumberExtension(Boolean critical, Object value)
            throws java.io.IOException {
        this(PKIXExtensions.CRLNumber_Id, critical, value, NAME, LABEL);
    }

    /**
     * Creates the extension (also called by the subclass).
     */
    protected CRLNumberExtension(ObjectIdentifier extensionId,
                                 Boolean critical, Object value, String extensionName,
                                 String extensionLabel) throws java.io.IOException {

        this.extensionId = extensionId;
        this.critical = critical.booleanValue();
        this.extensionValue = (byte[]) value;
        DerValue val = new DerValue(this.extensionValue);
        this.crlNumber = val.getBigInteger();
        this.extensionName = extensionName;
        this.extensionLabel = extensionLabel;
    }

    /**
     * Delete the attribute value.
     */
    public void delete(String name) throws java.io.IOException {
        if (name.equalsIgnoreCase(NUMBER)) {
            crlNumber = null;
        } else {
            throw new java.io.IOException("Attribute name not recognized by"
                    + " CertAttrSet:" + extensionName + ".");
        }
        encodeThis();
    }

    /**
     * Write the extension to the DerOutputStream.
     *
     * @param out the DerOutputStream to write the extension to.
     * @throws IOException on encoding errors.
     */
    public void encode(java.io.OutputStream out) throws java.io.IOException {
        DerOutputStream tmp = new DerOutputStream();
        encode(out, PKIXExtensions.CRLNumber_Id, true);
    }

    /**
     * Write the extension to the DerOutputStream.
     * (Also called by the subclass)
     */
    protected void encode(java.io.OutputStream out, ObjectIdentifier extensionId,
                          boolean isCritical) throws java.io.IOException {

        DerOutputStream tmp = new DerOutputStream();

        if (this.extensionValue == null) {
            this.extensionId = extensionId;
            this.critical = isCritical;
            encodeThis();
        }
        super.encode(tmp);
        out.write(tmp.toByteArray());
    }

    // Encode this extension value
    private void encodeThis() throws java.io.IOException {
        if (crlNumber == null) {
            this.extensionValue = null;
            return;
        }
        DerOutputStream os = new DerOutputStream();
        os.putInteger(this.crlNumber);
        this.extensionValue = os.toByteArray();
    }

    /**
     * Get the attribute value.
     */
    public java.math.BigInteger get(String name) throws java.io.IOException {
        if (name.equalsIgnoreCase(NUMBER)) {
            if (crlNumber == null) return null;
            else return crlNumber;
        } else {
            throw new java.io.IOException("Attribute name not recognized by"
                    + " CertAttrSet:" + extensionName + ".");
        }
    }

    /**
     * Return an enumeration of names of attributes existing within this
     * attribute.
     */
    public java.util.Enumeration<String> getElements() {
        AttributeNameEnumeration elements = new AttributeNameEnumeration();
        elements.addElement(NUMBER);
        return (elements.elements());
    }

    /**
     * Return the name of this attribute.
     */
    public String getName() {
        return (extensionName);
    }

    /**
     * Set the attribute value.
     */
    public void set(String name, Object obj) throws java.io.IOException {
        if (name.equalsIgnoreCase(NUMBER)) {
            if (!(obj instanceof java.math.BigInteger)) {
                throw new java.io.IOException("Attribute must be of type BigInteger.");
            }
            crlNumber = (java.math.BigInteger) obj;
        } else {
            throw new java.io.IOException("Attribute name not recognized by"
                    + " CertAttrSet:" + extensionName + ".");
        }
        encodeThis();
    }

    /**
     * Returns a printable representation of the CRLNumberExtension.
     */
    public String toString() {
        String s = super.toString() + extensionLabel + ": " +
                ((crlNumber == null) ? "" : Debug.toHexString(crlNumber))
                + "\n";
        return (s);
    }
}
